# 06 — Operations Runbook & Pitfall Index

Common tasks for the HA bot, plus the full pitfall index (each cost real debugging time — heed them).

## Common tasks

### Control a light / thermostat (needs USER token)
Mint a user token via the admin login_flow (see `01`), then:
```
POST /api/services/light/turn_on   {"entity_id":"light.living_room_lamp","brightness_pct":40}
POST /api/services/climate/set_temperature {"entity_id":"climate.sensi_thermostat","temperature":72}
POST /api/services/input_select/select_option {"entity_id":"input_select.govee_scene_tvbias","option":"Aurora"}
```

### Read state (system token is fine)
```
GET /api/states/light.living_room_lamp
GET /api/states/climate.sensi_thermostat
GET /api/camera_proxy/camera.tv_screen   # returns image bytes
```

### Refresh the TV snapshot on demand
```bash
ssh root@178.156.246.115 "adb connect 10.0.0.45:5555 && adb -s 10.0.0.45:5555 exec-out screencap -p > /tmp/t.png && mv /tmp/t.png /root/homeassistant/config/www/tv_snapshot.png && ls -la /root/homeassistant/config/www/tv_snapshot.png"
```

### Edit dashboard look (CSS/JS — hot, no rebuild)
Back up `.prev` first, edit `/root/ha-fusion/data/custom_style.css` or `custom_javascript.js`, user reopens. (Still needs Andrew's greenlight.)

### Restart only the affected container
```bash
ssh root@178.156.246.115 "docker restart homeassistant"   # HA core
ssh root@178.156.246.115 "docker restart ha-fusion"        # dashboard only
```
Never restart `mnfst-*`.

## Verification gates (run after ANY change)
```bash
ss -tlnp | grep 5050                                    # 100.119.118.54 NOT 0.0.0.0
curl -o /dev/null -w '%{http_code}' http://100.119.118.54:5050/   # 200
docker logs ha-fusion --since 3m | grep -i 'error\|auth'  # clean
docker logs homeassistant --since 3m | grep -i error      # clean
python3 -c "import yaml; yaml.safe_load(open('/root/ha-fusion/data/dashboard.yaml'))"  # valid
```
After a `docker logs` check, mind that **logs silently roll over** — check timestamps to separate current-boot from historical errors.

## PITFALL INDEX (the expensive lessons)

### Render / dashboard
- **Custom/source-patched UI renders SILENTLY EMPTY on client-side crash; server checks are false-positives.** HTTP 200 + valid YAML + clean logs while the user sees a blank dashboard. Browser-verify before prod.
- **`$states` is undefined during hydration.** Unguarded `$states[id]` in a main-grid Svelte component crashes the WHOLE app (every tile + sidebar → "Unknown"/blank). Guard: `id && $states ? $states[id] : undefined`.
- **`template` items don't work in the ha-fusion MAIN GRID** (sidebar-only). They fall through to an empty fallback. Main-grid custom UI = patch `custom_panel`.
- **Don't invent `custom_panel` fields** (`primary_row_id`) and **don't place a panel AS a view** — both blank the grid. See `references/custom-panel-schema.md`.
- **Storage-key mismatch = empty native-HA dashboard.** HA keys a storage-mode dashboard's config off the `id` in `.storage/lovelace_dashboards`, NOT `url_path`. Mismatch → blank "New section" even with built-in cards. Confirm via frontend websocket (`lovelace/config` → `config_not_found`). (Applies to HA's own Lovelace, not ha-fusion, but the bot may touch both.)
- **Custom HA Lovelace dashboards land users on the wrong page** — HA reserves `home`/`lovelace` for auto-Overview. Set the custom dashboard as default landing panel (`frontend.user_data_<USER_ID>` → `core.default_panel`). Companion app caches hard — test in a plain browser.
- **Prefer built-in HA cards** (`tile`+`light-brightness`, `thermostat`, `heading`) over custom JS cards (Mushroom/Bubble) — custom cards render silently empty when the JS module fails to register.

### Build / deploy
- **`npm run build` OOMs on the HA host (~700MB free).** Build the custom ha-fusion image on a 6GB+ box, `docker save | gzip | scp | docker load`.
- **Preserve the Tailscale bind** (`-p 100.119.118.54:5050:5050`) and `--restart unless-stopped` when recreating the container.

### Auth / tokens
- **System refresh token is read-only-ish** — 401s on `/api/services/*`, `/api/template`, `/api/onboarding`. Use a USER token (admin login_flow) for service calls.
- **`login_flow` `result` IS exchangeable** at `/auth/token` with `grant_type=authorization_code` (the earlier "transient code" belief was a wrong-password-hash artifact).
- **`.ha_token` is short-lived** (401s fast) — for entity read-back use `.storage/core.entity_registry` / `core.restore_state`, not a live API call.
- **Redaction mangles inline `Bearer <token>` and `$(...)`** in shell commands. Write a Python script that reads the token from its file, scp, run. Or use `execute_code` (avoids quoting) — BUT note execute_code is blocked under cron/untrusted profiles; fall back to write_file + terminal.
- **Password change:** base64(bcrypt(plaintext)), hashed INSIDE the container for matching lib version.

### Networking
- **`--network host` ≠ Tailscale routes in the container.** Verify device reachability from INSIDE the container (`docker exec homeassistant sh -c 'echo >/dev/tcp/<ip>/<port>'` — use `sh`, the HA image has no bash).
- **Android TV ADB binds local IP only** (`10.0.0.45`), reached via Shield-advertised subnet route. Android clients can't advertise routes for OTHER devices.
- **Sonos / sealed appliances:** need a desktop-OS subnet router on the LAN; the #1 gate is `PrimaryRoutes: None` on every peer (no router exists). Event-driven (UPnP) devices need a BIDIRECTIONAL route — one-way fails with `412` on `/ZoneGroupTopology/Event` and loads ZERO entities. Fix: static route `100.64.0.0/10 → router-LAN-IP` on the home router, or run HA on the LAN. Always confirm with `docker logs ... | grep -i sonos` + entity presence, not just a port probe.

### Integrations
- **`local_file` camera** can't use YAML platform setup in 2026.x — add as a config entry.
- **Weather `forecast` attribute removed** — use a trigger-template sensor calling `weather.get_forecasts`.
- **`calendar.*` entity exposes only the NEXT event** — use a trigger-template sensor calling `calendar.get_events` for an agenda.
- **HA crashes with `KeyError` naming the exact missing config-entry key** — add it and restart (common: `created_at`, `modified_at`, `discovery_keys:{}`, `subentries:[]`).
- **Storage.Store integrations** (Sensi/OAuth) need the wrapper envelope `{version, minor_version, key, data}` — flat JSON → `KeyError:'version'`.

## Source skills (the deep detail behind this handoff)
- `home-assistant` — deployment, auth, config entries, dashboards, subnet routing (the master skill)
- `ha-fusion-custom-build` — source patches, the `$states` crash, headless verify, auto-fit
- `govee-control` — the govee.py rig + scene artwork API
- `shield-control` — full ADB keyevent reference
- `homeassistant-dashboard-designer`, `home-assistant-best-practices` — Lovelace patterns
