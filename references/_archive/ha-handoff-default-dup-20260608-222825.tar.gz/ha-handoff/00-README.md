# Home Assistant Handoff Package

**Purpose:** Everything a dedicated HA-only Hermes/Telegram bot needs to operate Andrew's smart home with zero prior session context. Self-contained ground truth, verified against live state on **2026-06-04**.

**Read order:**
1. `01-infrastructure.md` — hosts, containers, networking, tokens, how to reach HA
2. `02-entity-inventory.md` — every entity the bot can touch (live, real IDs)
3. `03-ha-fusion-dashboard.md` — the dashboard: architecture, custom build, deploy/rollback
4. `04-govee-scenes.md` — Govee light + scene control (the `govee.py` rig + scene art)
5. `05-shield-tv.md` — Nvidia Shield via ADB + the TV snapshot camera feed
6. `06-operations-runbook.md` — common tasks, verification gates, the hard-won pitfalls
7. `08-new-bot-setup.md` — how to stand up the dedicated HA Telegram bot itself

## Golden rules (non-negotiable — Andrew's standing policy)
1. **NO infrastructure change without explicit greenlight.** Investigate read-only, present analysis + risks + rollback, then wait for "proceed." Applies to container swaps, config edits, integration adds, token changes.
2. **The dashboard is Tailscale-only** (`100.119.118.54:5050`). NEVER bind `0.0.0.0`. This is intentional security hardening.
3. **Custom/source-patched UI can render SILENTLY EMPTY.** Server checks (HTTP 200, valid YAML, clean logs) are FALSE-POSITIVES for client-side render crashes. Browser-verify (headless chromium) BEFORE any prod deploy.
4. **Always back up before editing** (`dashboard.yaml.prev`, `custom_style.css.prev`, etc.), validate config, restart only the affected container.
5. **Verify, don't claim.** The agent cannot screenshot a Tailscale-only dashboard from cloud — state plainly when pixel-level look is unverified and ask Andrew to confirm.

## One-paragraph system summary
Home Assistant (`homeassistant/home-assistant:stable`, `--network host`) runs on the **backup VPS 178.156.246.115** in Docker, config at `/root/homeassistant/config`. A separate **ha-fusion** dashboard container (amedello fork, custom-built image `ha-fusion:scene-art-dial-v2`) serves a Svelte UI bound Tailscale-only at `100.119.118.54:5050`. HA reaches LAN devices (Nvidia Shield, Sonos) over Tailscale. Govee lights are controlled OUT-OF-BAND via the cloud `govee.py` script (not a native HA integration) and surfaced on the dashboard through `input_select` + automations. The Sensi thermostat, Sonos, Met.no weather, a local calendar, and a TV-snapshot camera are native HA integrations.
