# 05 — Nvidia Shield TV (ADB) & TV Snapshot Feed

## The Shield
- Model `mdarcy`. LAN IP `10.0.0.45`, Tailscale IP `100.69.145.58`.
- Controlled via **ADB over Tailscale** from the HA host (`178.156.246.115`), which runs the adb client + authorized key.
- HA integration: `androidtv` config entry uses the **Tailscale IP** (`100.69.145.58:5555`) because the HA container can't reach the LAN IP directly. Surfaces as `media_player.unnamed_device`.

### Prerequisites
- Tailscale active on VPS + Shield, **subnet routing** enabled on Shield (advertises `10.0.0.0/24`, approved in Tailscale admin console).
- Shield Developer Options → Network debugging ON (Android auto-disables this after a timeout — if `adb connect` fails after working, re-enable).
- ADB RSA key authorized once on the TV screen.

### Connect + control
```bash
ssh root@178.156.246.115 "adb connect 100.69.145.58:5555"
adb shell input keyevent KEYCODE_DPAD_CENTER     # select
adb shell input keyevent KEYCODE_HOME            # home
adb shell input keyevent KEYCODE_MEDIA_PLAY_PAUSE
adb shell input keyevent KEYCODE_VOLUME_UP
```
Full keyevent list + "pull up a title without auto-playing (Plex)" flow in the `shield-control` skill.

## TV snapshot camera feed (the "TV feed" tile)
Shows what's on the TV as a still image on the dashboard. **Andrew wants this always-on.**

### Pipeline
1. **Host-side bash script** (runs on `178.156.246.115` — it has adb + key, NOT the container):
   ```bash
   adb connect 10.0.0.45:5555
   adb -s 10.0.0.45:5555 exec-out screencap -p > /tmp/tmp.png && \
     mv /tmp/tmp.png /root/homeassistant/config/www/tv_snapshot.png
   ```
   - Use `exec-out` (no sdcard round-trip). Atomic `mv` so the dashboard never reads a half-written file; leave the prior snapshot on failure.
   - Capture takes ~15s (Shield PNG encode+transfer) — fine for a periodic still, NOT live.
   - `/root/homeassistant/config/www` → `/config/www` in the container.
2. **systemd timer** (`OnUnitActiveSec=30`, `OnBootSec=30`) runs it every 30s, on the HOST.
3. **`local_file` camera** — YAML platform setup is REMOVED in HA 2026.x ("does not support platform setup"). Add as a config entry in `.storage/core.config_entries`: domain `local_file`, `options:{file_path:/config/www/tv_snapshot.png, name:TV Screen}`, empty `data:{}`. Restart → `camera.tv_screen`.

### Rendering on the dashboard — two options
- **Main-grid `camera` item:** `{type: camera, entity_id: camera.tv_screen, stream: false}`. ALWAYS draws a name+state overlay ("TV Screen / Idle") you can't disable.
- **Cleaner (no overlay, size control):** a sidebar/section `template` `<img>` from the no-auth `/local/` path:
  ```yaml
  - type: template
    template: >-
      <img src="http://178.156.246.115:8123/local/tv_snapshot.png?{{ now().timestamp()|int }}"
           style="width:100%;border-radius:0.5rem"/>
  ```
  The `?{{ now().timestamp() }}` cache-buster forces a refetch. (Note: `template` items are SIDEBAR-only in ha-fusion main grid — for a main-grid spot use the `camera` item.)

### Pitfalls
- **DRM apps return BLACK frames** (Netflix/Prime/Disney+ via HDCP). Launcher/screensaver/YouTube/games/Plex(menus) capture fine. This is expected, not a bug.
- **Verify the image actually serves** (don't trust state): `GET /api/camera_proxy/camera.tv_screen` returns PNG/JPEG bytes (check magic header), and `ls -la` the snapshot file to confirm the timer is refreshing it.
- **ADB hangs HA core if the device is unreachable** — verify connectivity + port FROM INSIDE the container before adding/relying on the androidtv entry.
