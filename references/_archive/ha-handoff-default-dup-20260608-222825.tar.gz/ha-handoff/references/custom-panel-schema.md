# custom_panel Canonical Schema (amedello fork)

VERIFIED to render (recovered by building one panel in the UI editor and reading back its output). Use this EXACTLY.

```yaml
- type: custom_panel
  id: <int>
  rows:
    - type: slider          # brightness slider bound to a light
      id: <int>
      entity_id: light.lantern_lamp
    - type: buttons         # NOTE: row holds `items:`, NOT `buttons:`
      id: <int>
      columns: <int>        # buttons per row
      items:
        - id: <int>
          entity_id: input_select.govee_scene_lantern   # opens scene picker modal
```
Row types: `slider`, `buttons`, `sensor`, `camera`.
The panel MUST be nested as an ITEM inside a section: `view → sections → section → items → custom_panel`.

## Two things that broke the first attempt (BOTH must be avoided)
1. **`primary_row_id` is FABRICATED — never add it.** The editor's real output has none. Adding it caused a silent-empty render.
2. **Placing the panel AS a view blanks the whole dashboard.** `views: - type: custom_panel` produces a view with no `sections` → ha-fusion renders the empty "Welcome Home / Open dashboard menu" fallback, wiping the main grid. The panel lives under `section.items`.

## dial display mode (the climate tile, added in scene-art-dial-v2)
This is a SOURCE patch in `CustomPanel.svelte` (display:'dial'), not a stock row type. Binds standardized climate attrs of `climate.sensi_thermostat`. Live clock = a local `setInterval` (there is NO `$clock` store). Ring color: cooling=blue, heating=orange, idle=grey. To change the dial you must rebuild the image (Path B). The fields added to `CustomPanelItem` (Types.ts): `display`, `climate_entity`, `humidity_entity`.

## Failure mode = silent client-side empty render
A bad `custom_panel` does NOT fail gracefully — it can blank the entire dashboard while EVERY server check passes (YAML parses, curl serves config, HTTP 200, docker logs clean). Visible ONLY in a browser/screenshot. Tailscale-only → agent can't screenshot from cloud. **Safe rollout:** keep `dashboard.yaml.prev`, build ONE panel on the simplest room, have Andrew screenshot-confirm BEFORE rolling out. Fallback (Plan A): place the `light` button and its scene `input_select` button side-by-side — both work, zero fragility, fully verifiable.
