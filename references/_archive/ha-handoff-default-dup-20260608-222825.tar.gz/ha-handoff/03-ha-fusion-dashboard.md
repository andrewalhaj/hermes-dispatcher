# 03 — ha-fusion Dashboard

The smart-home dashboard. A Svelte app (amedello fork of matt8707/ha-fusion) talking to HA over websocket.

## Live deployment (verified 2026-06-04)
- **Container:** `ha-fusion`, image `ha-fusion:scene-art-dial-v2` (a CUSTOM-built image, not a registry pull)
- **Bind:** `100.119.118.54:5050` — **Tailscale-only. NEVER 0.0.0.0.**
- **Data dir:** `/root/ha-fusion/data` (mounted `/app/data`)
- **Access:** `http://100.119.118.54:5050` from any tailnet device
- **Base fork image (for rollback):** `ghcr.io/amedello/ha-fusion:v2026.5.3`

### Data files (`/root/ha-fusion/data/`)
- `configuration.yaml` — `hassUrl`, `locale`, `token` (long-lived HA token), `custom_css`, `custom_js`
- `dashboard.yaml` — views/sections/cards (the layout). Backups: `dashboard.yaml.prev` … `.prev5`
- `custom_style.css` — fonts, dial CSS, widget styling. **Hot-reloads, no restart.**
- `custom_javascript.js` — the auto-fit/responsive-zoom script. **Hot-reloads.**

## Why it's a CUSTOM image (what was patched into source)
Four features required patching Svelte source + rebuilding (config/CSS alone can't do them). All are LIVE in `scene-art-dial-v2`:
1. **Scene-art thumbnails in the picker** — stock picker is text+iconify only. Patched `InputSelectModal.svelte` (attach `image` per option) + `Select.svelte` (render `<img>`); 260 real Govee scene PNGs baked into `static/`.
2. **Climate dial** — a circular thermostat tile. `template` items DON'T work in the main grid, so this is a `display:'dial'` mode added to `CustomPanel.svelte` (big target temp, `HVAC_ACTION • time`, room label, current/humidity/fan rows, ring color by hvac_action). Binds `climate.sensi_thermostat`.
3. **Bigger calendar font** — pure CSS (`.cal-item .ev` / `.cal-item .wh`) — this one is NOT a source patch, lives in `custom_style.css`.
4. **Auto-fit / responsive zoom** — `custom_javascript.js`, NOT a rebuild (see below).

## Layout model (dashboard.yaml)
```
theme: godis            # bundled: godis, muted, contrast
views: [ {name, icon, id, sections:[ {type:horizontal-stack, sections:[ {name, items:[...]} ]} ]} ]
sidebar: [ {type:time|date|sensor|weather|weather-forecast|divider|graph|template|...} ]
```
- **Main-grid item types (amedello fork):** `configure | button | conditional_media | picture_elements | camera | empty | custom_panel`. **`template` is SIDEBAR-ONLY** — a template item in the main grid renders SILENTLY BLANK.
- `button` = universal card (switch/light/climate/sensor/media_player).
- `media` card = now-playing/TV feed (main grid; uses a `conditional:` list of entity_ids).
- `custom_panel` (fork) = light + scene picker + sensor/camera rows in one tile. **Canonical schema** (verified) is in `references/custom-panel-schema.md` — do NOT invent `primary_row_id`, do NOT place the panel AS a view.
- Left sidebar is LOCKED/perfect per Andrew — **do not touch it.**

## Feature mechanics (where each dashboard widget gets its data)
- **Weather strip:** trigger-template sensor calling `weather.get_forecasts` every 30 min → stores `forecast[:7]` attr → sidebar `template` renders the row. (HA removed the native `forecast` attribute.)
- **Calendar agenda:** trigger-template sensor calling `calendar.get_events` (HA-start + every 15 min) → full list in an attribute → sidebar `template` renders. Reads `calendar.family`.
- **TV snapshot:** `camera.tv_screen` OR a `template` `<img>` from `/local/tv_snapshot.png?<cachebuster>` (cleaner — no name/state overlay). See `05`.
- **Server CPU/RAM:** `command_line` sensors reading `/proc` (HA is `--network host` → reflects the host).
- **Govee scenes:** `custom_panel` button bound to `input_select.govee_scene_*` opens the (patched, image-thumbnail) picker modal.

## Editing & deploying — TWO paths

### Path A — CSS / JS / dashboard.yaml only (NO rebuild, low risk)
Hot-reloads (user just reopens). Still requires Andrew's greenlight for any change.
```bash
ssh root@178.156.246.115
cp /root/ha-fusion/data/custom_style.css /root/ha-fusion/data/custom_style.css.prev   # ALWAYS back up
# edit the file
# dashboard.yaml: validate before relying on it
python3 -c "import yaml; yaml.safe_load(open('/root/ha-fusion/data/dashboard.yaml'))"
```
Rollback: restore the `.prev`. No container restart needed for css/js; dashboard.yaml hot-reloads too.

### Path B — source patch + image rebuild (HIGH risk, mandatory browser verify)
Use ONLY when the feature can't be done in data files (new card behavior, source-level UI). Full procedure in the **`ha-fusion-custom-build` skill** — summary:
1. Clone fork at pinned tag: `git clone --depth 1 --branch v2026.5.3 https://github.com/amedello/ha-fusion.git`
2. Patch Svelte source. **GUARD EVERY `$states` ACCESS** — `$states` is `undefined` before the websocket connects; an unguarded top-level `$states[id]` in a main-grid component crashes hydration and blanks the WHOLE app (HTTP 200, clean logs — server checks are false-positives). Use `id && $states ? $states[id] : undefined`.
3. Build on a BEEFY box (HA host has ~700MB free → `npm run build` OOMs): `docker build -t ha-fusion:<feature> .`
4. **MANDATORY headless browser verify BEFORE prod:** run the new image on a localhost test port with the real HASS_URL, SSH-tunnel it, drive snap chromium (`/snap/bin/chromium` via Playwright `executablePath`), capture `pageerror`/`console`, count "Unknown", assert tiles render. This catches the hydration crash logs miss.
5. **Pause for Andrew's "proceed."** Then: snapshot container config, back up data files, `docker save | gzip | scp | docker load`, validate dashboard.yaml, `docker rm -f ha-fusion` + recreate with IDENTICAL config (preserve `-p 100.119.118.54:5050:5050` and `--restart unless-stopped`), re-verify bind is Tailscale + re-run browser probe on prod.

### Rollback (instant)
Recreate the container on `ghcr.io/amedello/ha-fusion:v2026.5.3` (or the prior custom tag) and restore the `.pre-<feature>` data files. ~10s. HA core unaffected.

## Verification gates (every dashboard change)
```bash
ss -tlnp | grep 5050                          # 100.119.118.54 NOT 0.0.0.0
curl -o /dev/null -w '%{http_code}' http://100.119.118.54:5050/        # 200
curl -s http://100.119.118.54:5050/ | grep -o '<your view/section name>' # config actually loaded
docker logs ha-fusion --since 3m | grep -i 'error\|auth'               # clean
```
**The agent CANNOT screenshot a Tailscale-only dashboard from cloud.** Verify everything reachable, then state plainly that pixel-level look is unverified and ask Andrew to confirm. Don't claim a visual result you couldn't see.
