# 01 — Infrastructure & Access

Verified live 2026-06-04.

## Hosts
| Role | IP | Tailscale IP | Notes |
|---|---|---|---|
| HA + dashboard host (**backup VPS**) | `178.156.246.115` | `100.119.118.54` | Runs `homeassistant`, `ha-fusion`, and the Manifest router containers |
| Primary server | `5.78.238.81` | — | NOT the HA host; runs main Hermes infra |
| Nvidia Shield (Android TV) | `10.0.0.45` (LAN) | `100.69.145.58` | model `mdarcy`; ADB over Tailscale |

SSH into the HA host: `ssh root@178.156.246.115` (key `~/.ssh/id_ed25519`).

## Containers on the HA host (live)
```
ha-fusion        ha-fusion:scene-art-dial-v2              100.119.118.54:5050->5050/tcp
homeassistant    homeassistant/home-assistant:stable      (network host, 8123)
mnfst-manifest-1 manifestdotbuild/manifest:latest         0.0.0.0:2099->2099  (NOT HA — leave alone)
mnfst-postgres-1 postgres:16-alpine                       5432  (NOT HA — leave alone)
```
**Only `ha-fusion` and `homeassistant` are in scope for the HA bot.** Never touch the `mnfst-*` containers.

## Home Assistant
- **Base URL:** `http://178.156.246.115:8123`
- **Config dir (on host):** `/root/homeassistant/config`
- **Runs `--network host`** — required so HA can reach Tailscale/LAN devices. Docker does NOT propagate Tailscale subnet routes into the container, so inside the container use **Tailscale IPs** for devices, verify with `docker exec homeassistant sh -c 'echo >/dev/tcp/<ip>/<port>'`.
- Key files:
  - `configuration.yaml` — integrations
  - `.storage/core.config_entries` — UI/added integrations (JSON)
  - `.storage/core.entity_registry` — all entities
  - `.storage/auth` — users + refresh tokens
  - `home-assistant.log` — live log
  - `www/tv_snapshot.png` — TV snapshot (served at `/local/tv_snapshot.png`, no auth)

## Auth tokens (how the bot talks to HA)
Two token types — pick the right one or you'll waste time on 401s:

- **System refresh token** (`token_type:"system"`, never expires) — in `.storage/auth` → `data.refresh_tokens[]`. **READ-ONLY in practice**: works for `/api/states`, `/api/states/<id>`, history. **Gets 401 on service calls** (`/api/services/*`), `/api/template`, `/api/onboarding`.
- **User token via admin login flow** — REQUIRED for service calls (turning things on/off, `calendar.create_event`, template render). Flow:
  ```
  POST /auth/login_flow {client_id, redirect_uri, handler:["homeassistant",null]} -> flow_id
  POST /auth/login_flow/<flow_id> {client_id, username, password}  -> result (an auth code)
  POST /auth/token  grant_type=authorization_code&code=<result>&client_id=...  -> access_token (183-char JWT, 30-min expiry)
  ```
  Admin creds live in HA (`hermes_admin`). Store in the bot's `.env`, do not inline in shell (redaction mangles `Bearer <token>` and `$(...)`).
- **ha-fusion's own token:** a dedicated **long-lived** token (3650-day) lives in `/root/ha-fusion/data/configuration.yaml` → `token:`. This authenticates the DASHBOARD to HA headlessly. Independently revocable (Profile → Long-lived tokens → "ha-fusion"). Do not reuse it for bot API calls — mint a separate one.

### Token pitfall (critical)
Hermes's secret-redaction rewrites secret-looking strings to `***` **inside** shell commands — breaks `TOKEN=$(...)` and inline `Authorization: Bearer <token>`. **Fix:** write a Python script that reads the token from its file (`open('/config/.ha_token').read().strip()`), `scp` it over, run `python3 /tmp/x.py`. Python file content is not mangled. `.ha_token` is short-lived (401s fast) — for read-back use `.storage/core.entity_registry` / `core.restore_state` instead.

## Networking facts that bite
- **`--network host` + Docker ≠ Tailscale routes.** Always verify device reachability FROM INSIDE the container, not just the host.
- **Android TV ADB binds to the LOCAL IP only** (`10.0.0.45`), not Tailscale. Reached via Tailscale **subnet routing** advertised by the Shield (`10.0.0.0/24`, approved in the Tailscale admin console).
- **Sonos / sealed appliances can't run Tailscale** — they need a desktop-OS subnet router on the LAN. Android clients CANNOT advertise routes. Event-driven devices (Sonos UPnP) need a BIDIRECTIONAL route or the integration loads zero entities (412 on `/ZoneGroupTopology/Event`). Full detail in `06-operations-runbook.md`.

## Quick health checks (read-only, safe)
```bash
ssh root@178.156.246.115 "docker ps --format '{{.Names}}\t{{.Status}}\t{{.Ports}}'"
ssh root@178.156.246.115 "ss -tlnp | grep 5050"   # MUST show 100.119.118.54, not 0.0.0.0
curl -o /dev/null -w '%{http_code}\n' http://100.119.118.54:5050/   # dashboard (from a tailnet host)
```
