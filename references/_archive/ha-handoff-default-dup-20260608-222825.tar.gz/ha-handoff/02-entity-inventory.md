# 02 — Entity Inventory (live, 2026-06-04)

Real entity IDs pulled from `.storage/core.entity_registry` on the HA host. These are what the bot issues service calls against. **Re-derive any time** with:
```bash
ssh root@178.156.246.115 "python3 -c \"import json;d=json.load(open('/root/homeassistant/config/.storage/core.entity_registry'));[print(e['entity_id']) for e in d['data']['entities']]\""
```

## Integrations installed (config_entries domains)
`analytics, androidtv, backup, go2rtc, google_translate, local_calendar, local_file, met, mobile_app, radio_browser, sensi, shopping_list, sonos, sun`

## Entity counts by domain
`automation:7, binary_sensor:24, calendar:1, camera:1, climate:1, device_tracker:1, event:1, input_select:7, light:7, notify:1, number:2, person:1, sensor:137, switch:7, todo:1, tts:1, weather:1`

## Controllable entities (the ones the bot acts on)

### Lights (7) — these are **Govee** devices, but exposed as HA `light.*`
> NOTE: brightness/on-off work as normal HA `light.*` entities. **SCENES are NOT a native HA capability** — they go through the Govee `input_select` + automation bridge (see `04-govee-scenes.md`).

| Entity | Device | SKU |
|---|---|---|
| `light.living_room_lamp` | Living Room Lamp | H1401 |
| `light.lantern_lamp` | Lantern Floor Lamp | H1630 |
| `light.tv_bias_light` | TV (bias lighting) | H6604 |
| `light.bathroom_1` | Bathroom 1 | H6006 |
| `light.bathroom_2` | Bathroom 2 | H6006 |
| `light.bathroom_3` | Bathroom 3 | H6006 |
| `light.office_light` | Andrew's Office | H1310 (fan w/ light) |

### Climate (1) — Sensi thermostat
- `climate.sensi_thermostat` — standardized attrs: `temperature` (target), `current_temperature`, `hvac_action` (idle/cooling/heating), `hvac_mode`, `fan_mode`.
- Related switches: `switch.sensi_thermostat_display_humidity`, `..._continuous_backlight`, `..._display_time`, `..._keypad_lockout`, `..._fan_support`, `..._aux_heat`, `..._humidification`.
- The dashboard renders this as a **custom circular dial** (see `03`).

### Scene pickers (7 `input_select.*`) — one per Govee light
`input_select.govee_scene_lrl` (living room lamp), `..._lantern`, `..._tvbias`, `..._bath1`, `..._bath2`, `..._bath3`, `..._officelt`. Each holds that device's full scene-name list; changing the selection fires an automation that calls the Govee scene shell_command. See `04`.

### Camera (1)
- `camera.tv_screen` — a `local_file` camera fed by an ADB screencap of the Shield every 30s (`/config/www/tv_snapshot.png`). DRM apps (Netflix/Prime/Disney+) show BLACK frames (HDCP); launcher/YouTube/games capture fine. See `05`.

### Weather (1)
- `weather.forecast_forecast` — Met.no (free, no key). HA home lat/long MUST be set or it returns garbage. The ha-fusion forecast strip is fed by a trigger-template sensor calling `weather.get_forecasts` (HA removed the `forecast` attribute), NOT the dead native attribute.

### Calendar (1)
- `calendar.family` — a `local_calendar` (currently dummy/seed data; Andrew's real calendars not yet linked). The dashboard agenda reads a trigger-template sensor calling `calendar.get_events` (a `calendar.*` entity only exposes the NEXT event natively). Swapping in real calendars later = change the entity_id only, no rebuild.

### Media player — Nvidia Shield
- Surfaces from the `androidtv` integration as `media_player.unnamed_device` (HA 2026.6 can't rename via API — rename in UI if needed). Used by the dashboard `media` card / now-playing.

## Read-only sensors of interest
- 137 `sensor.*` — includes Sensi humidity/fan, server CPU%/RAM% `command_line` sensors (HA is `--network host` so `/proc` reflects the HOST), Met.no, and the calendar-agenda + weather-forecast template sensors that feed the dashboard.
- `device_tracker:1`, `person:1` — presence.

## Service-call cheatsheet (needs a USER token, not the system token)
```
light.turn_on  {entity_id: light.living_room_lamp, brightness_pct: 50}
light.turn_off {entity_id: light.bathroom_1}
climate.set_temperature {entity_id: climate.sensi_thermostat, temperature: 72}
climate.set_hvac_mode  {entity_id: climate.sensi_thermostat, hvac_mode: cool}
input_select.select_option {entity_id: input_select.govee_scene_tvbias, option: "<scene name>"}  # fires Govee scene
```
