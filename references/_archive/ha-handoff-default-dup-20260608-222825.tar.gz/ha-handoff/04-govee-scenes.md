# 04 — Govee Lights & Scenes

**Key architectural fact:** Govee lights are controlled TWO different ways depending on what you want:
- **On/off, brightness, color, temp** → works as native HA `light.*` entities (service calls) AND via the `govee.py` cloud script.
- **SCENES (Sunrise, Aurora, Forest, DIY…)** → NOT a native HA capability. Routed through `govee.py` (official Govee OpenAPI `dynamic_scene`) wired into HA via `input_select` + automations + `shell_command`.

## The govee.py rig
Script: `~/.hermes/scripts/govee.py` (on the main Hermes host) and a copy used by HA shell_commands. Talks to the official Govee OpenAPI (`openapi.api.govee.com/router/api/v1`).
```bash
python3 ~/.hermes/scripts/govee.py list
python3 ~/.hermes/scripts/govee.py on  "Living Room Lamp"
python3 ~/.hermes/scripts/govee.py off "Bathroom 1"
python3 ~/.hermes/scripts/govee.py color 255 100 0 "TV"
python3 ~/.hermes/scripts/govee.py brightness 50 "Bathroom 1"
python3 ~/.hermes/scripts/govee.py temp 4000 "Living Room Lamp"
```

## The 9 Govee devices
| Name | SKU | HA entity | Caps |
|---|---|---|---|
| Living Room Lamp | H1401 | `light.living_room_lamp` | RGB, temp, brightness, scenes, music |
| Lantern Floor Lamp | H1630 | `light.lantern_lamp` | RGB, segments, temp, gradient, DreamView |
| TV | H6604 | `light.tv_bias_light` | RGB, segments, gradient, DreamView, HDMI |
| Bathroom 1/2/3 | H6006 | `light.bathroom_1/2/3` | RGB, temp, brightness, scenes |
| Andrew's Office Fan | H1310 | `light.office_light` | RGB, segments, fan toggle/speed, airflow |
| Bathroom (group) | SameModeGroup | — | on/off only |
| Andrew's Office (group) | SameModeGroup | — | on/off only |

## How scenes work end-to-end
1. **Control path (official, reliable):** `POST /device/control` with `capability.type=devices.capabilities.dynamic_scene`, `instance=lightScene|diyScene`, `value=<scene dict like {"paramId":110,"id":128}>`. Scene lists per device come from `POST /device/scenes` (built-in) and `POST /device/diy-scenes` (DIY). Counts vary per SKU (H6604 ≈ 237, H6006 ≈ 56) — generate live, don't assume.
2. **HA wiring:** one `input_select.govee_scene_<slug>` per light holds the scene-name list; an automation per light triggers on the input_select change (condition excludes the placeholder), action = `shell_command.govee_<slug>_scene` passing `{{ trigger.to_state.state }}`. The 7 input_selects: `_lrl, _lantern, _tvbias, _bath1, _bath2, _bath3, _officelt`.
3. **Dashboard:** a `custom_panel` button bound to the input_select opens the picker modal.

## Scene artwork (the thumbnails baked into the dashboard)
- **Official OpenAPI returns NO artwork** — only `{name, paramId, id}`.
- Real thumbnails come from an **undocumented, AUTH-FREE** endpoint:
  `https://app2.govee.com/appsku/v1/light-effect-libraries?sku=<SKU>` with headers ONLY `AppVersion: 6.5.02` + `User-Agent: GoveeHome/6.5.02 (...)`. No login/token. Returns categories→scenes→`iconUrls` (normal/pressed/dark — prefer `dark` for dark UI). Images on a public CloudFront CDN (auth-free fetch).
- ~96% coverage across Andrew's SKUs (260 PNGs baked into the custom image). Fetcher: `govee-control` skill's `scripts/fetch_scene_art.py`.
- It's undocumented/fragile (a 401/403 is the canary that Govee gated it) and ToS-gray — use for the VISUAL layer only, NEVER as the control mechanism (control stays on official paramId/id).

## Pitfalls
- **Quoting:** `"Andrew's Office Fan"` must be escaped `''` inside YAML single quotes or `check_config` fails ("expected <block end>").
- **`!include`d input_select file must NOT repeat the top-level `input_select:` key** (configuration.yaml already nests it under `input_select: !include`). Include the bare dedented mapping or HA errors "required key 'options' not provided" and sets up 0 entities.
- **Service calls need a USER token** (system refresh token 401s on `/api/services/*` and `/api/template`).
