# 08 — Standing Up the Dedicated HA Telegram Bot

Goal: a SECOND Telegram bot, separate from the main Hermes bot, scoped to Home Assistant only. It should load this handoff package + the HA skills and nothing else noisy.

## Architecture decision: use a separate Hermes PROFILE
A single Hermes gateway maps ONE `TELEGRAM_BOT_TOKEN`. To run a second, independent bot with its own personality, skills, memory, and token, create a **dedicated profile** (Andrew already uses profiles: `executor`, `stable-2026-06-02`). A profile has its own `skills/`, `plugins/`, `cron/`, `memories/`, `.env`, and config — perfect isolation so the HA bot can't drift into general-purpose behavior.

Profiles live at `~/.hermes/profiles/<name>/`. Run anything under it with `hermes --profile <name> ...`.

## Steps (all gated on Andrew's greenlight — this creates infra)

### 1. Create a BotFather bot
Andrew (or the bot owner) messages @BotFather → `/newbot` → gets a `TELEGRAM_BOT_TOKEN`. This is a manual, human step.

### 2. Create the profile
```bash
hermes profile create ha-bot     # confirm exact subcommand with `hermes profile --help`
```

### 3. Write the token + allowlist into the profile .env
Use the safe Python method (NOT inline — redaction mangles tokens). Target `~/.hermes/profiles/ha-bot/.env`:
- `TELEGRAM_BOT_TOKEN=<token>`
- `TELEGRAM_ALLOWED_USERS=8878729385`  (Andrew's Telegram user id — restrict, don't allow-all)
- HA access for the bot's tools: `HA_BASE_URL=http://178.156.246.115:8123` and a DEDICATED HA token (`HA_REFRESH_TOKEN=...` system token for reads; mint a separate user token path for service calls).

### 4. Give the bot ONLY the HA context
- Copy/symlink the HA skills into the profile's `skills/`: `home-assistant`, `ha-fusion-custom-build`, `govee-control`, `shield-control`, `homeassistant-dashboard-designer`, `home-assistant-best-practices`.
- Point it at this handoff: copy `~/.hermes/references/ha-handoff/` into the profile (or symlink) so the bot can read 00–06.
- Seed the profile MEMORY.md with the Golden Rules from `00-README.md` + the host/token facts from `01`.

### 5. Set an HA-scoped personality
```bash
hermes --profile ha-bot config set agent.personalities.ha \
  "You are a Home Assistant operations bot for Andrew. Scope: HA, ha-fusion dashboard, Govee lights/scenes, Sensi thermostat, Nvidia Shield, the TV snapshot feed. Direct, task-focused, no filler. NEVER make an infrastructure change (container swap, config edit, integration add, token change) without Andrew's explicit greenlight — present analysis + risks + rollback first. The dashboard is Tailscale-only (100.119.118.54:5050); never bind 0.0.0.0. Browser-verify custom UI before any prod deploy."
hermes --profile ha-bot config set display.personality ha
```

### 6. Restrict toolsets (optional but recommended)
The HA bot mainly needs `terminal` (SSH to the HA host), `file`, and `web`. Trim others to keep its context lean and its blast radius small.

### 7. Install + start the profile's gateway
```bash
printf 'Y\nY\n' | hermes --profile ha-bot gateway install --force
hermes --profile ha-bot gateway status
tail -20 ~/.hermes/profiles/ha-bot/logs/gateway.log   # expect: telegram connected
```

### 8. Verify end-to-end
- Message the new bot on Telegram → it responds.
- Ask it to read a light's state → it SSHes / hits the HA API and returns real state.
- Confirm it refuses an infra change without greenlight (policy check).

## Gotchas (from gateway-platform-setup skill)
- **Token redaction:** never write the token via inline `echo`/`printf` with the literal value — use the Python-variable method in the `gateway-platform-setup` skill.
- **Allowlist is mandatory** — without `TELEGRAM_ALLOWED_USERS` (or `TELEGRAM_ALLOW_ALL_USERS=true`) every user is denied silently.
- **`.env` changes need a gateway restart** to take effect: `hermes --profile ha-bot gateway restart`.
- **Linger:** `sudo loginctl enable-linger $USER` so the service survives SSH logout.
- **Profile isolation rule:** this main session must NOT edit the `ha-bot` profile's skills/memory/cron unless explicitly told to — and vice versa.

## What the bot can do on day one (capabilities backed by this package)
- Read any entity state; control lights, thermostat, scenes (with a user token).
- Refresh + report the TV snapshot; drive the Shield via ADB.
- Explain/operate the ha-fusion dashboard; safely edit CSS/JS (greenlit); run the full custom-build + browser-verify flow for source features.
- Diagnose the classic failure modes (empty dashboard, 401s, Tailscale routing, Sonos 412) using the pitfall index in `06`.
