User Andrew Alhaj. Direct, task-focused — no fluff. Accuracy > speed. Telegram: 8878729385.
§
Memory: Hot (this) → Knowledge (LanceDB, `python3 ~/.hermes/scripts/knowledge.py search "q"`) → Person (Honcho). Load knowledge-store skill for config/tool/system details.
§
HA dashboard = ha-fusion (amedello fork) http://100.119.118.54:5050, Tailscale-only. Full build/deploy/browser-verify procedure + pitfalls: skill `ha-fusion-custom-build` + knowledge.py search "ha-fusion dashboard". Never deploy untested image to prod.
§
Hermes multi-host. Profiles: default, executor, stable-2026-06-02, ha-bot (HAJarvis @HAjarviss_bot, Telegram-only HA bot). delegation.max_spawn_depth=1 (NOT 2 — depth 2 tested + reverted), max_concurrent_children=3. Full profile/cron/systemd detail: knowledge.py search "profiles cron channel". Cron notifs → Telegram Cron Jobs CHANNEL -1003947663220 (NOT DM).
§
Andrew requires explicit approval before any infrastructure changes — updates, patches, config edits, migrations. No auto-patching. Present analysis + risks + rollback plan. Wait for greenlight. He'll say "proceed" or "don't do anything yet."
§
NO changes to AGENTS.md, SOUL.md, skills, config, or reference docs without written report FIRST. Report → wait for greenlight → execute. Applies to default AND ha-bot profiles. ALWAYS create backup before any write. Andrew enforces this: "Report of changes should be listed to me prior to any changes being done."
§
Skills are the proper domain expertise layer — do NOT trim or consolidate into AGENTS.md. Andrew: "It is also my mistake to say to trim the skills as those serve as proper layer." Architecture: SOUL.md (identity, loaded per message), AGENTS.md (procedures, reference), skills/ (domain expertise, loaded on demand). Each does its job.
§
Server upgrades are on the table for infrastructure/memory improvements. Andrew: "Servers can be upgraded as needed." Don't self-censor proposals that need more RAM, CPU, or storage — present the option and let him decide.