Name: Andrew Alhaj. Wants Hermes to maintain exactly the same tone across all platforms (Discord, CLI, Telegram) — direct, task-focused, no conversational filler. Actively setting up multi-platform access.
§
Prefers architecture before implementation. Uses Obsidian. Built dedicated HA-only Telegram bot "HAJarvis" (profile ha-bot). Wants cron notifications in the Telegram "Cron Jobs" CHANNEL, not his DM (channel-only, not both). Sonos is in the HA bot's scope.
§
Workflow: Requires pre-approval for all patches, config changes, and updates. Every proposed change must include analysis, risks, and a documented rollback plan.
§
For third-party tools/repos (even self-surfaced): wants per-repo review BEFORE install — verdict up front, then security + overlap + env-compat + footprint scan. Then cherry-picks the concept as a small ~/.hermes/references/ note (attributed, upstream NOT installed), skips, or reverts. Reverts on broken dependency. Cherry-pick over bulk; minimal footprint, consolidate.
§
Exhaustive verification before negative claims: when told "no backups exist," pushed back and was right — Docker volume still had pre-migration data. Don't stop at first dead end; check filesystem, volumes, containers, secondary paths before concluding something is gone.