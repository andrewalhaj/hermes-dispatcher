---
name: memory-discipline
description: "Memory hygiene: compaction, audit, rent test, lifecycle, and the daily morning-audit tier-review workflow. Keep memory useful and lean. Load alongside factual-discipline."
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [memory, hygiene, optimization, anti-bloat]
    created_by: agent
load_when:
  - "memory optimization or hygiene is discussed"
  - "memory limits are changed"
  - "memory audit is requested"
  - "always — this skill defines memory quality standards"
---

# Memory Discipline

Memory is injected into EVERY turn. Every character you store costs tokens forever. Entries must pay rent.

## Pre-Flight: Honcho Coexistence

If Honcho is the active memory provider (`memory.provider: honcho` in config.yaml), the memory system operates differently:

- **Hot store** (`MEMORY.md`): Still active and injected every turn. Apply the rent test, compact, and audit normally.
- **Warm/cold tiers**: Frozen — Honcho handles user modeling automatically via dialectic reasoning. Do not suggest promotion/demotion moves involving warm or cold. The Obsidian vault `hermes-memories/archive/` directory holds pre-Honcho tier archives.
- **Audit cadence**: Skip tier-based audits. Focus only on hot store compaction when memory exceeds 60%. The `morning-audit` skill automatically switches to Honcho mode.
- **Honcho tools**: `honcho_conclude` for saving durable facts, `honcho_search` for semantic recall, `honcho_profile` for peer card. The built-in `memory` tool still operates on hot store only.
- **Pitfall: `honcho_conclude` requires a `delete_id`** — when correcting a stale conclusion, `honcho_conclude` needs the internal ID of the stale entry, which is not surfaced by `honcho_search` or `honcho_profile`. For bulk peer-card corrections, use `honcho_profile(card=[...])` with the full rewritten card array instead. It's simpler and avoids the ID-hunting problem.
- **Bridge**: If configured, a cron job dumps Honcho conclusions to Obsidian vault periodically for local searchability. This does not affect hot store management.

## The Rent Principle

Before saving anything to memory, apply this test:

> *Will this fact prevent the user from having to repeat or correct themselves in a future session?*

If yes → save it. If no → skip it. "Nice to have" is not good enough. Memory is not a logbook — it's a cache of durable corrections and preferences.

## What Never Belongs in Memory

The persona already blocks the worst offenders, but reinforce these:

- **Stale-by-design facts**: PR numbers, issue numbers, commit SHAs, "fixed bug X," "submitted PR Y," file counts, "Phase N done" — anything that will be stale in a week
- **Procedural outcomes**: session results, task completions, what was built, what was deployed
- **Rediscoverable facts**: things a tool call or skill can find in under 5 seconds
- **Redundant information**: anything already in a skill that loads automatically
- **Raw credentials**: API keys, tokens, admin passwords (they're in .env or auth.json)

Use `session_search` to recall past outcomes. Use skills for procedures. Use memory for durable facts.

## Compaction Rules

When writing or replacing a memory entry:

1. **Lead with the key fact.** No preamble. "Obsidian vault at /root/Documents/Obsidian Vault" — not "The user has configured an Obsidian vault located at..."
2. **Drop qualifiers.** "Manifest routes all tiers to deepseek-v4-pro" — not "Currently, Manifest is configured to route all complexity tiers to..."
3. **One entry, one topic.** Don't bundle unrelated facts. It makes replacement harder.
4. **Use target='user' for user facts, target='memory' for environment.** Don't mix.
5. **Max ~200 chars per entry.** If it's longer, split it or compress it.

## Audit Cadence

**Post-infrastructure-change audit (mandatory)**: After any migration, topology change, or provider switch (Neon → VPS, adding load balancer, changing model providers), audit ALL memory entries for staleness. Infrastructure changes often invalidate multiple entries at once — database URLs, provider names, instance counts, disk sizes. Delaying this audit causes the agent to cite wrong architecture in future sessions. Check each entry against current state and replace stale facts immediately.

**Post-rollback audit (mandatory)**: After a rollback, audit memory as the final step of the rollback procedure — do not wait for the user to ask. Rollbacks often revert topology facts (multi-host → single-host, shared DB → local, LB URL → localhost) and the memory entries describing those facts go stale immediately. A rollback is not complete until memory reflects the restored state.

Specific checks during post-rollback audit:
1. **Topology facts**: instance counts, hostnames, base_url values, cron job counts — these go stale immediately on rollback. Replace each entry with current state.
2. **Duplicate entries**: rollbacks often create duplicates when stale facts are replaced but not removed. After fixing topology entries, scan for near-identical pairs (e.g., two approval-rule entries, two "save to files" entries) and remove the older/longer version. Duplicates waste token budget and create confusion about which entry is authoritative.
3. **Provider references**: if the rollback changed database providers (Neon → local, Supabase → local), purge any provider-specific entries that no longer apply.
4. **Report**: list what was changed, removed, and consolidated so the user can verify.

**With Honcho active**: Audit only when memory exceeds 60% — focus on compaction, not tier promotion/demotion.

**Without Honcho (full manual tier system)**: Every ~10 turns or when memory exceeds 60%:

1. Read current memory entries (`read_file /root/.hermes/memories/MEMORY.md`)
2. For each entry, apply the rent test
3. Entries that fail: replace with compact version, or remove
4. Entries that overlap: consolidate into the best single version
5. Report: what was changed and why

## Morning Audit Workflow (daily / on-demand tier review)

Triggered when the user says "morning audit", "memory audit", or "audit memory". This is the
step-by-step procedure for a full review of the three-tier memory system. **Never make changes
without user confirmation** — present candidates, wait for explicit "yes"/"approved".

### Pre-flight: Honcho coexistence

If `memory.provider: honcho`, the Obsidian warm/cold tier system is **frozen legacy** (Honcho
handles user modeling via dialectic reasoning). In that mode: audit/compact the hot store
(`MEMORY.md`) normally, add a header "Honcho active — tier system frozen", and skip warm/cold
promotion/demotion. Honcho tools: `honcho_search`, `honcho_profile`, `honcho_conclude` (built-in
`memory` tool still operates on hot store only). **Cron caveat:** Honcho tools are NOT available
in cron context (`_cron_skipped = True`, Port #4053) — use the Honcho Python SDK directly. Full
SDK bridge pattern: `references/honcho-cron-bridge.md`.

### Steps (full manual tier system, Honcho inactive)

1. **Read hot store** — `read_file /root/.hermes/memories/MEMORY.md`. Parse entries (delimited by
   `§`); note total chars, count, each entry's subject + size.
2. **Check recent relevance** — for each hot entry, `session_search(query="<key terms>", sort="newest", limit=3)`.
   2-3 searches covering all entries. A hit = topic appeared recently = strong rent signal.
3. **Read warm directory** — `search_files(pattern="*.md", target="files", path="/root/Documents/Obsidian Vault/hermes-memories/warm/")`.
   For each, check if loaded in recent sessions.
4. **Check cold directory (if non-empty)** — same pattern under `cold/`. Only flag cold entries
   mentioned in a recent session (candidate for warm promotion).
5. **Apply the rent test per entry** (see The Rent Principle above), backed by Step 2 evidence.
6. **Present report** in this format:

```
☕ Morning Memory Audit — [date]

Hot: X/Y,000 chars (Z%) — N entries

| # | Entry | Size | Rent | Signal |
|---|-------|------|------|--------|
| 1 | ... | ~N | Passes/Fails | Found in M/N recent sessions |

Warm: N notes  |  Cold: N notes

Candidates:
  → Promote (warm→hot): [list or "none"]
  → Demote (hot→warm): [list or "none"]
  → Archive (warm→cold): [list or "none"]
  ✂ Compact: [list or "none"]

[Verdict: No changes needed / Confirm above?]
```

### Audit rules

1. **Never move without confirmation.** Present candidates, wait for "yes"/"approved".
2. **Err toward keeping hot.** A false demotion costs a future round-trip; a false keep costs ~140 chars.
3. **Demote, don't delete.** Hot→warm preserves the fact; warm→cold archives it. Only delete truly
   dead entries (obsolete, zero future value).
4. **One change at a time.** Don't batch a promote + demote + compaction into one approval.
5. **Warm notes get individual files** — `warm/topic-name.md` with wikilinks to related notes.
6. **Cold notes get date-stamped context** — `cold/2026-06-01-topic-name.md` for traceability.
7. **Log all moves** — append to `hermes-memories/audit-log.md`:
   ```
   ## YYYY-MM-DD
   - Promoted: [entry] warm→hot (reason)
   - Demoted: [entry] hot→warm (reason)
   - Archived: [entry] warm→cold (reason)
   ```

### Audit edge cases

- **Hot store empty:** "Hot store is empty. Nothing to audit." Still check warm for promotions.
- **Warm/cold empty:** Skip that column; note "no warm notes yet" / normal for new systems.
- **Entry spans multiple topics:** Flag for splitting (e.g. "Entry 2 bundles Manifest config +
  executor profile + cron job. Suggest splitting into 2-3 focused entries.").
- **session_search returns noise:** If key terms are too generic, note "Session search inconclusive
  — relying on agent judgment."

## Replace, Don't Append

When updating an existing fact (e.g., Manifest model changes), use `memory(action='replace', old_text=...)` — never `add` a second entry about the same topic. Duplicate/contradictory entries are worse than no entry.

## Token Budget Awareness

Memory is charged to every turn at ~0.25 tokens per character. At 4000 chars, that's ~1000 tokens per turn just for memory. A 200-char entry costs ~50 tokens per turn. Over a 50-turn session: 2,500 tokens. An entry must save at least one round-trip correction to break even.

Thresholds for concern:
- < 30% full: healthy, no action
- 30-60% full: normal, audit every ~15 turns
- 60-80% full: prioritize compaction, be selective
- > 80% full: aggressive compaction or bump limit (with awareness of the rent cost)

## Recovery from Bloat

If memory exceeds 80% and audit doesn't free enough space:

1. Don't panic-save. Don't delete entries just to make room.
2. Compact aggressively — most entries can be shortened 40-60%.
3. If still tight, bump `memory_char_limit` in 1000-char increments.
4. Never reset memory without user approval (`hermes memory reset` wipes everything).

## Hot → Cold Offload Pattern (with LanceDB)

When MEMORY.md nears its char limit, move stable infrastructure facts to the knowledge store (LanceDB) rather than deleting them. This preserves the knowledge while freeing the hot tier. Steps:

1. **Identify candidates.** Entries tagged to infrastructure, config, server topology, or tool quirks that are stable (not session-volatile) and would be expensive to re-derive.
2. **Store to cold tier FIRST.** Use `KNOWLEDGE_TAGS` and `KNOWLEDGE_PRIORITY=high`:
   ```bash
   cd ~/.hermes && KNOWLEDGE_TAGS="infrastructure,config" KNOWLEDGE_PRIORITY=high \
     python3 scripts/knowledge.py store "Full fact text here with all detail preserved"
   ```
3. **Verify retrievability.** Run a semantic search for the fact before trimming hot memory:
   ```bash
   python3 scripts/knowledge.py search "key terms from the fact"
   ```
   If it doesn't surface, the fact isn't safely offloaded — don't trim yet.
4. **Trim the hot entry to a pointer.** Replace the verbose entry with a compact version:
   `HA dashboard: Tailscale-only 100.119.118.54:5050. Full detail: knowledge.py search "ha-fusion dashboard".`
   The pointer exists so the agent knows where to find the detail without holding it in context.
5. **Never trim before verifying.** Hot memory is truncated by the `memory` tool — if you delete the entry before confirming it's in LanceDB, it's gone. Store first, verify, then trim.

**Why the pointer matters.** Without a pointer, the agent has no signal that the knowledge exists in cold storage and will re-derive it from scratch — wasting the session that originally captured it. A one-line pointer costs ~10 chars and saves a full rediscovery.
