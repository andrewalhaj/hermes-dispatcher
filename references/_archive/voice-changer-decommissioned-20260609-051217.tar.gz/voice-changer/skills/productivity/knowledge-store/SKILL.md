---
name: knowledge-store
description: "Semantic knowledge base for agent institutional knowledge — tool quirks, config details, device maps, bug workarounds, and setup notes. LanceDB-backed, local, unlimited."
version: 3.1.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [knowledge, memory, vector-db, lancedb, semantic-search]
    created_by: agent
load_when:
  - "user asks about a system configuration, tool quirk, or past bug fix"
  - "agent needs to recall institutional knowledge about this user's setup"
  - "hot memory is full and knowledge offloading is needed"
---

# Knowledge Store — LanceDB Semantic Memory

Persistent, searchable knowledge base for everything the agent needs to remember about this user's system, tools, and environment. Complements Honcho (user modeling) and hot memory (session-critical context).

## Quick Reference

```bash
# Search
python3 ~/.hermes/scripts/knowledge.py search "manifest routing fallback"

# Store a fact
KNOWLEDGE_TAGS="govee,bug" KNOWLEDGE_PRIORITY="high" \
  python3 ~/.hermes/scripts/knowledge.py store "Fact text here"

# Store with contextual prefix (overlap chunking + Haiku/synthetic prefix)
KNOWLEDGE_TAGS="infrastructure" \
  python3 ~/.hermes/scripts/knowledge.py store --contextualize "Fact text here..."

# Index vault changes (standard heading-based chunking)
python3 ~/.hermes/scripts/knowledge.py index-vault

# Index vault with contextualized chunking
python3 ~/.hermes/scripts/knowledge.py index-vault --contextualize

# Contextualize a single file (chunk → prefix → embed → store)
python3 ~/.hermes/scripts/knowledge.py contextualize-file ~/path/to/file.md

# Status
python3 ~/.hermes/scripts/knowledge.py status

# Recent entries
python3 ~/.hermes/scripts/knowledge.py recent 10

# Build the wikilink/cross-reference knowledge graph (v3.0)
python3 ~/.hermes/scripts/knowledge.py build-graph

# Query graph neighbors of a page (multi-hop; GRAPH_HOPS=2 default)
python3 ~/.hermes/scripts/knowledge.py graph-query infrastructure-summary

# Run benchmark evaluation (v3.0 — 12-query harness for retrieval quality)
python3 ~/.hermes/scripts/knowledge.py eval

# Check for stale infra/config facts (dry-run default; --live for connectivity probes)
python3 ~/.hermes/scripts/knowledge.py stale-check

# Index changed reference/vault files since last run (mtime-based; safe for cron)
python3 ~/.hermes/scripts/knowledge.py auto-index

# Compile search results with citations + gap analysis (no LLM, pure compilation)
python3 ~/.hermes/scripts/knowledge.py summarize "how does memory work across sessions"
```

### v2.0: Contextualized Embeddings

The contextualized embedding pipeline wraps each chunk with a **situating prefix** before embedding, so the vector captures *what document this is from and where it sits in the document structure*, not just the raw text.

**Pipeline:**
1. **Overlap-based paragraph chunking** — splits markdown into paragraphs on `\n\n+`, groups into ~800-char chunks with 1-paragraph overlap. Each chunk tracks its heading breadcrumb.
2. **Contextual prefix generation** — sends chunk + source context to Manifest's Haiku route (`claude-haiku-4-5`) for a 1-sentence situating sentence.
3. **Synthetic floor** — if Manifest/Haiku is unreachable (Anthropic provider inactive, timeout, etc.), falls back to `"This passage is from {filename}: {heading context}."` — measurably better than plain text via title-keyword re-injection.
4. **Embed** `"{prefix}\n\n{chunk_body}"` — the vector now encodes both *what* the text says and *where* it's from.
5. **Sha256 cache** — chunks are cached by body hash. Re-contextualizing the same file skips unchanged chunks.

**Columns:** `context_prefix` (the situating sentence) and `body_hash` (sha256 for cache dedup) — both added via schema migration on first v2.0 access. Existing plain-text embeddings survive untouched with NULL values.

**Cost:** negligible. Haiku ~$1/MTok input, one-shot at ingest. On this setup Anthropic is inactive via Manifest, so the synthetic floor handles everything automatically.

### v3.0: Hybrid Retrieval + Knowledge Graph

`search()` is no longer pure vector cosine. The v3.0 pipeline:

1. **LRU embedding cache** — repeated queries skip re-encoding (256-entry cap, 30-min TTL). Transparent.
2. **Hybrid vector + BM25 fusion** — runs a LanceDB FTS keyword search alongside the vector search. **Adaptive weighting:** bare-identifier queries (e.g. `DATABASE_URL`, `max_spawn_depth`, error codes — detected by underscores / all-caps / single-token) weight BM25 at 0.75; prose queries stay vector-dominant at 0.6. This fixes the long-standing "exact config-key search scores negative" failure. Degrades gracefully to vector-only if FTS is unavailable.
3. **Priority + recency scoring** — `priority` (critical/high/normal/low) and `stored_at` now actually affect ranking: importance multiplier + exponential recency boost (14-day half-life).
4. **MMR diversity** — when `top_k > 3`, near-duplicate results (cosine > 0.85) are dropped so you don't get 5 variants of the same fact.
5. **Knowledge graph boost** — `build-graph` scans `~/.hermes/references/` (and the Obsidian vault / `WIKI_PATH` if present) for `[[wikilinks]]`, bare `filename.md` cross-references, and frontmatter `related:`/`tags:`. Edges land in `~/.hermes/knowledge_db/graph.sqlite`. `search()` gives a small confirmatory boost to results whose source page is a graph-neighbor of a top-3 hit. No-op until `build-graph` runs.

**Rebuild the graph** after adding or heavily cross-linking reference docs: `python3 ~/.hermes/scripts/knowledge.py build-graph`. It's cheap (zero LLM, pure file scan + SQLite).

### Synthesis convention: name the gaps (anti-fabrication)

When synthesizing an answer from `search()` results, **explicitly flag what the knowledge base does NOT contain** rather than papering over it. After presenting what was found, add a short "Gaps" note listing query terms that returned zero or weak (low-score) hits. This is the anti-fabrication principle (SOUL.md) applied to retrieval — borrowed from GBrain's `think` command. A retrieval answer that hides its blind spots is worse than one that names them. If every relevant query came back empty, say so plainly: "Nothing in the knowledge base covers X" — don't improvise.

## How Hermes Uses It

**Session-start ritual (MANDATORY):**
When the user's first message relates to infrastructure, system config, tools, or any topic that might have been discussed before, query LanceDB BEFORE responding:
```bash
python3 ~/.hermes/scripts/knowledge.py search "<topic from user's first message>"
```
This prevents reteaching. The most common failure mode: agent answers from hot memory only, misses 77 relevant facts in LanceDB, user has to repeat themselves. Do NOT wait until you "need" deeper knowledge — assume the user's first infrastructure question needs a LanceDB check.

**During a session:**
- Hot memory (injected every turn) contains 2-3 critical pointers only
- When anything technical arises — even if it feels familiar — do a LanceDB search. The 2,200-char hot memory is NOT a reliable source for config details, server topology, or tool quirks. Hot memory is a pointer to the real knowledge in LanceDB.
- New things I learn get stored immediately with appropriate tags and priority

**Post-session auto-capture:**
After each session with significant changes, run the session capture script to auto-extract learnable facts:
```bash
python3 ~/.hermes/scripts/session_capture.py "<summary of session changes and decisions>"
```
Use `--dry-run` first to preview, then without it to store permanently. The script identifies:
- Changes, fixes, additions, removals
- Corrections and clarifications
- Command invocations with explanations
- Config changes

**Search is semantic** — "env secrets file" finds ".env read_file restriction" because the embedding matches conceptually, not literally.

## Priority Levels

| Priority | When to use |
|----------|------------|
| `critical` | The one thing that prevents disaster if forgotten |
| `high` | Config details, tool quirks, device maps — reviewed every related query |
| `normal` | Procedural notes, historical context |
| `low` | Nice-to-have but not essential |

## Tags (Current)

`govee`, `manifest`, `config`, `env`, `secrets`, `gateway`, `discord`, `telegram`, `obsidian`, `vault`, `honcho`, `memory`, `cron`, `jobs`, `profiles`, `executor`, `user`, `preferences`, `communication`, `bug`, `workaround`, `script`, `commands`, `system`, `server`, `routing`, `devices`, `audit`, `skills`, `rules`, `factual`

## Storage

- **Location:** `~/.hermes/knowledge_db/` (LanceDB columnar format)
- **Embedding model:** `all-mpnet-base-v2` (768-dim, best local quality — upgraded from MiniLM 2026-06-04). Rollback via `knowledge_minilm_backup.parquet` + reverting MODEL_NAME in knowledge.py.
- **Concurrent-safe:** LanceDB supports multi-process reads/writes
- **Backup:** Included in `hermes-backup-*.tar.gz` via the daily backup cron

## Indexing the Vault

After writing new changelogs or snapshots to the Obsidian vault, re-index:

```bash
# Standard heading-based chunking (legacy, plain text embeddings)
python3 ~/.hermes/scripts/knowledge.py index-vault

# Contextualized chunking (overlap chunks + situating prefixes)
python3 ~/.hermes/scripts/knowledge.py index-vault --contextualize
```

The contextualized mode chunks all markdown files by paragraph overlap, generates situating prefixes via Manifest Haiku (with synthetic fallback), and embeds `{prefix}\n\n{body}` instead of raw text. Archive and backup directories are excluded in both modes.

## Memory Architecture

| Layer | System | Purpose | Size Limit |
|-------|--------|---------|------------|
| Hot | `MEMORY.md` | Session-critical pointers only | 2,200 chars |
| Knowledge | LanceDB | Agent institutional knowledge | Unlimited |
| Person | Honcho | User patterns, preferences | Cloud, managed |

Hot memory should NEVER contain knowledge that LanceDB can serve. If you see a fact in hot memory that belongs in LanceDB, move it.

## Pitfalls

**The reteaching trap:** When LanceDB has 77+ facts but the agent doesn't query it at session start, every infrastructure question triggers rediscovery — the user teaches you again, you store it again, and the cycle repeats. The fix is the session-start ritual above. If the user ever says "I have to reteach you" or "what happened to this?", the agent failed to query LanceDB. Fix immediately.

**Durable reference files beat LanceDB for topology.** For complex infrastructure (multi-host, nginx configs, DB locations), write a reference file under `~/.hermes/references/` in addition to LanceDB facts. LanceDB is semantic search — great for "how do I reset the admin password?" but less reliable for "what's the current state of ALL my servers?" A single markdown file read at session start is stronger than 10 fragmented LanceDB facts.

**Contextualized vs plain-text coexistence:** The v2.0 schema adds `context_prefix` and `body_hash` columns to the existing table via auto-migration. Old rows get NULL values — they continue to work for search but lack the situating prefix. Re-indexing with `--contextualize` will add new contextualized entries alongside them (different body hashes due to different chunking, so no collisions). Old entries can be deleted manually if desired, but coexistence is harmless — search returns both.

**Heading context stability:** The overlap chunker anchors heading context to the FIRST paragraph in each chunk, not the last. Using the last paragraph is wrong — a high-level heading like "## Cron Jobs" resets the breadcrumb from "Infrastructure > Routing > DB Topology" to "Infrastructure > Cron Jobs", losing the earlier structure. First-paragraph anchor is the most stable descriptor of where the chunk begins. Do not "fix" this to track the deepest or last heading — it's intentionally first.

**Retrieval pipeline (v3.0 — implemented):** `~/.hermes/references/retrieval-pipeline-techniques.md` documented 5 post-retrieval scoring techniques cherry-picked from the memory-lancedb-pro OpenClaw plugin. Items 1-4 (LRU embedding cache, priority/recency scoring, BM25 hybrid fusion, MMR diversity) are now LIVE in `search()` as of v3.0. The knowledge-graph layer (from the GBrain cherry-pick, `~/.hermes/references/gbrain-cherry-pick.md`) is also live via `build-graph`/`graph-query`. Item 5 (cross-encoder rerank, ~80MB model download) remains the only un-implemented future option — gate it behind a flag if ambiguous-query quality ever needs it.
