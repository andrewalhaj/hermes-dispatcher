# Session Wipe Procedure

Full-clean-slate wipe of all sessions and messages from `state.db`. Use when the infrastructure stabilizes
after a migration and old troubleshooting/debugging sessions are noise, not value.

## Pre-flight

- All durable knowledge MUST be in LanceDB, references/, skills, and hot memory BEFORE wiping.
  Sessions are conversation flow; facts extracted from them should already be in durable storage.
- Verify no cron job `context_from` references depend on session IDs (list all jobs, check the field).
  Jobs that use `session_search` as a tool will just find an empty DB — not broken, just quiet.

## Procedure

```bash
# 1. Create final backup
cp ~/.hermes/state.db ~/.hermes/state_final_YYYYMMDD.db

# 2. Wipe via python3 (sqlite3 binary not guaranteed on all hosts)
python3 << 'PYEOF'
import sqlite3
db = "/root/.hermes/state.db"
conn = sqlite3.connect(db)
cur = conn.cursor()

# Count before
cur.execute("SELECT COUNT(*) FROM sessions")
cur.execute("SELECT COUNT(*) FROM messages")
print(f"Before: {cur.fetchone()[0]} sessions, {cur.fetchone()[0]} messages")

# Wipe
cur.execute("DELETE FROM messages")
cur.execute("DELETE FROM sessions")
if "session_events" in [r[0] for r in cur.execute("SELECT name FROM sqlite_master WHERE type='table'")]:
    cur.execute("DELETE FROM session_events")
if "message_fts" in [r[0] for r in cur.execute("SELECT name FROM sqlite_master WHERE type='table'")]:
    cur.execute("DELETE FROM message_fts")

conn.commit()
cur.execute("VACUUM")

# Verify
cur.execute("SELECT COUNT(*) FROM sessions")
cur.execute("SELECT COUNT(*) FROM messages")
print(f"After: {cur.fetchone()[0]} sessions, {cur.fetchone()[0]} messages")
cur.execute("PRAGMA integrity_check")
print(f"Integrity: {cur.fetchone()[0]}")
conn.close()
PYEOF

# 3. Verify file shrunk
ls -lh ~/.hermes/state.db ~/.hermes/state_final_YYYYMMDD.db
```

## What survives

| Layer | Survives? |
|-------|-----------|
| Hot memory (MEMORY.md) | ✅ |
| LanceDB knowledge base | ✅ |
| Honcho (cloud) | ✅ |
| References/ | ✅ |
| Config + .env | ✅ |
| Cron jobs | ✅ |
| Skills | ✅ |

## What's lost

- All session transcripts (FTS5 search returns nothing)
- Session history in gateway UI
- The ability to `session_search` for past troubleshooting flow

## Risks

- **Low** if durable knowledge is up to date. The sessions being purged should be troubleshooting artifacts,
  not irreplaceable reference material. If in doubt, keep the backup — it's a 37MB SQLite file.
- New sessions begin accumulating immediately as the conversation continues — the wipe only clears history,
  it doesn't stop future recording.

## Alternative: CLI Bulk Deletion (no direct SQLite)

When you need to delete ALL sessions via the supported CLI path rather than raw SQLite:

```bash
# List all session IDs, pipe to delete
hermes sessions list 2>&1 | grep -oP '2026\d{4}_\d{6}_[a-f0-9]+' | while read id; do
  echo "Deleting: $id"
  hermes sessions delete --yes "$id" 2>&1
done

# Then optimize to reclaim disk space
hermes sessions optimize
hermes sessions stats
```

**Note:** The currently active session cannot be deleted — it will persist after the wipe. The DB file shrinks dramatically after optimize (8.1MB → 0.1MB typical).
