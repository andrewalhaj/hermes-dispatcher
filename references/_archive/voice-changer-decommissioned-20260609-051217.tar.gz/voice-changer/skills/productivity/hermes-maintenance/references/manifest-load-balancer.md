# Manifest Load Balancer — nginx on VPS

Set up nginx as a reverse proxy in front of two Manifest instances, with passive health checks and firewall hardening.

## Architecture

```
[hermes] → [nginx LB :8080 on VPS]
              ├── manifest:2099 on VPS (127.0.0.1) → postgres:5432 (Docker internal)
              └── manifest:2099 on Hermes host (5.78.238.81, fw-gated) → postgres:5432 (VPS, fw-gated)
```

## Step 1: Expose Hermes host Manifest (firewall-gated)

Edit `/root/manifest/docker-compose.yml` — change port binding from `127.0.0.1` to `0.0.0.0`:

```yaml
ports:
  - "0.0.0.0:${PORT:-2099}:${PORT:-2099}"
```

Restart, then apply iptables to allow only the VPS:

```bash
iptables -I INPUT -p tcp --dport 2099 -s 127.0.0.1 -j ACCEPT
iptables -I INPUT -p tcp --dport 2099 -s VPS_IP -j ACCEPT
iptables -A INPUT -p tcp --dport 2099 -j DROP
```

**Pitfall:** The ACCEPT rules must be inserted BEFORE the DROP rule. Use `-I` (insert at top) for ACCEPT, `-A` (append) for DROP. Test from VPS with `curl http://HERMES_IP4:2099/api/v1/health`.

## Step 2: Lock VPS Manifest to localhost

Edit `/root/manifest/docker-compose.yml` on the VPS:

```yaml
ports:
  - "127.0.0.1:${PORT:-2099}:${PORT:-2099}"
```

Restart Docker Compose. Manifest is now only reachable via nginx on the same host.

## Step 3: Install and configure nginx

```bash
apt-get install -y nginx
```

Create `/etc/nginx/sites-available/manifest-lb`:

```nginx
upstream manifest_backend {
    server 127.0.0.1:2099 max_fails=2 fail_timeout=30s;      # VPS local
    server HERMES_IP:2099 max_fails=2 fail_timeout=30s;       # Hermes host
}

server {
    listen 8080;

    location / {
        proxy_pass http://manifest_backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 60s;
        proxy_next_upstream error timeout http_502 http_503 http_504;
        proxy_next_upstream_tries 2;
    }
}
```

Enable and test:

```bash
ln -sf /etc/nginx/sites-available/manifest-lb /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl restart nginx
```

## Step 4: Point Hermes at the LB

```bash
hermes config set model.base_url "http://VPS_IP:8080/v1"
```

The `patch` and `write_file` tools are blocked on `config.yaml`. Always use `hermes config set`.

## Step 5: Verify round-robin

```bash
for i in 1 2 3 4; do
  curl -s http://VPS_IP:8080/api/v1/health
done
```

Different `uptime_seconds` values confirm both backends are serving traffic.

## Passive Health Checking

When a backend fails 2 consecutive requests (`max_fails=2`), nginx marks it down for 30 seconds (`fail_timeout=30s`). `proxy_next_upstream` triggers failover on error, timeout, or 502/503/504 responses.

## Rollback

```bash
hermes config set model.base_url "http://localhost:2099/v1"
```

Both Manifest instances share the same PostgreSQL (on VPS, Docker postgres). No data consistency issues when switching between direct and LB routing.

## Pitfalls

- **Config changes must use `hermes config set`**: The Hermes config.yaml is protected from the standard file tools.
- **Docker Compose restarts need `background=true`**: Compose up starts long-lived services. Foreground mode is rejected.
- **IPv6 vs IPv4**: Some VPS providers default to IPv6-only. Use `curl -s4 ifconfig.me` to get IPv4 explicitly, and test connectivity with `-4` flag.
- **nginx passive health checks only**: No active health probing in nginx open-source. A backend stays marked up until it actually fails a proxied request.
