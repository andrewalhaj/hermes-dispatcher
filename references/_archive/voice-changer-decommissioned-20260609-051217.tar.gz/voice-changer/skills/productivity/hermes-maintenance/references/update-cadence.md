# Safe Update Strategy: Hermes Core + Infrastructure

## Update surface

| Component | Mechanism | Risk |
|---|---|---|
| Hermes Core | `hermes update` (git pull + pip reinstall) | Medium |
| Bundled Node | Updated with core | Low |
| Config | `hermes config migrate` | Medium |
| Skills | Curator (7d) + manual patches | Low |
| Manifest Router | Separate service | Low |
| Honcho | Cloud (managed) | None |
| Cron jobs | Manual | Low (scripts, not LLM) |

## The safe pattern

```
Present analysis → Get greenlight → Pre-snapshot → Update → Post-snapshot → Test → Verify → Lock
```

### 0. Present analysis first (MANDATORY gate)

Before touching anything, present to the user:

1. What's pending (`hermes update --check`)
2. What could break (breaking config changes, API deprecations, tool removals)
3. Risk assessment (low/medium/high with justification)
4. Recommendation (proceed / wait / skip this cycle)

Do NOT execute the update. Wait for explicit greenlight. This gate applies to `hermes update`, any config changes, skill patches that modify system behavior, and profile operations. It does NOT apply to user-requested content work (writing, research, code review) — only to infrastructure changes.

### 1. Pre-update safety net

```bash
hermes update --check                    # See what's coming
hermes profile create pre-update-YYYY-MM --clone-all  # Full snapshot
```

Force backup regardless of config:
```bash
hermes update --backup --yes
```

Or enable auto-backup permanently:
```bash
hermes config set updates.pre_update_backup true
```

### 2. Update

```bash
hermes update --yes --backup
```

`--yes` auto-accepts config migration. `--backup` forces backup even if `pre_update_backup: false`.

### 3. Post-update snapshot

```bash
hermes profile create post-update-YYYY-MM --clone-all
```

### 4. Test in isolation

```bash
hermes --profile post-update-YYYY-MM chat -q "verify all skills, cron jobs, and platform connections"
```

Check:
- Skills load without errors
- Cron jobs fire normally
- Platform connections (Discord, Telegram) functional
- Manifest router healthy
- Memory/knowledge DB accessible

### 5. Lock and cleanup

After confirming stability (wait a week):

```bash
# Replace stable snapshot
hermes profile create stable-YYYY-MM --clone-all
hermes profile delete stable-OLD-DATE

# Remove pre/post snapshots (keep pre-update for a week as safety)
hermes profile delete pre-update-YYYY-MM
hermes profile delete post-update-YYYY-MM
```

### Rollback if broken

```bash
hermes profile use pre-update-YYYY-MM   # Instant revert
```

## Cadence

**Weekly:** `hermes update --check` — monitor what's pending. Don't pull every week.

**Monthly:** Actual update. 99-commit gaps are tolerable for a month but not longer — risk of straddling a breaking change that requires intermediate migration steps you'd skip if you fell further behind.

**On-demand:** When a specific feature/fix is needed or a critical security patch drops.

## What NOT to update in lockstep with core

- **Skills** — curator handles staleness on its own 7-day cycle. Don't batch-update skills just because core updated.
- **Manifest** — separate service, separate update cycle. Only update when there's a reason.
- **Cron jobs** — scripts are stable. Audit monthly, not per-update.
- **Profiles** — rotate stable snapshots after confirmed successful updates, not before.

## Profile snapshot sizing

- `--clone-all`: 200–500MB (copies everything including cache, backups, state-snapshots). Use for major version jumps.
- `--clone`: ~10MB (config, .env, SOUL.md only). Sufficient for config tweaks or minor updates.
- For monthly Hermes core updates: `--clone-all` is right — the risk justifies the disk cost.

### Post-clone cleanup (critical)

`--clone-all` copies junk directories that should NOT live in snapshots. After every clone-all, immediately strip:

```bash
rm -rf ~/.hermes/profiles/<name>/backups/
rm -rf ~/.hermes/profiles/<name>/state-snapshots/
rm -rf ~/.hermes/profiles/<name>/image_cache/
rm -rf ~/.hermes/profiles/<name>/audio_cache/
rm -rf ~/.hermes/profiles/<name>/cache/
```

This can save 200MB+ per snapshot. The node/ directory (~204MB) is a bundled dependency — leave it.
