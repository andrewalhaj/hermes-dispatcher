---
name: token-optimization
description: "Audit and reduce Hermes token spend: session DB queries, Manifest routing, delegate-first tool access, lean profiles, static knowledge."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [token-optimization, cost, delegation, manifest, routing, profiles, auditing]
    related_skills: [subagent-driven-development, hermes-agent]
---

# Token Optimization

Reduce per-session and per-turn token spend without degrading output quality. Covers auditing, model routing, delegate-first tool access, lean profiles, and static knowledge files.

## When to Load

Load when:
- User asks to audit token spend, cut costs, or "stop tokenmaxxing"
- User asks to configure Manifest or model routing
- Setting up delegation discipline or lean executor profiles
- User wants per-toolset token overhead analysis
- Creating cron-based self-audit jobs

## Core Principles

1. **Audit first, cut second.** Query the session DB to find WHERE tokens went before proposing cuts.
2. **Profile-based, reversible changes.** Every change should be undoable with a single command. No destructive edits.
3. **Delegate everything heavy.** >50 lines of tool output → subagent. Browser, MCP, heavy file ops → delegate.
4. **Cheap model for background work.** Cron jobs, kanban workers, delegated subagents → DeepSeek V4 Pro (or cheapest capable model).
5. **Static knowledge over re-discovery.** CONTEXT.md files and Obsidian/wiki reads replace terminal/file exploration.

## Step-by-Step Workflow

### 1. Self-Audit (no changes yet)

Query the session database for the last 14 days:

```python
import sqlite3, json

db = sqlite3.connect("/root/.hermes/state.db")
db.row_factory = sqlite3.Row

sessions = db.execute("""
    SELECT id, title, model, started_at, message_count,
           tool_call_count, input_tokens, output_tokens,
           estimated_cost_usd
    FROM sessions
    ORDER BY started_at DESC
    LIMIT 50
""").fetchall()
```

For each session, count tool patterns from the messages table:
```sql
SELECT id, role, tool_calls, tool_name
FROM messages
WHERE session_id = ?
ORDER BY id
```

Flag violations:
- **>100K input tokens + ZERO delegate_task** → context saturated with direct work
- **>8 web_search + ZERO delegation** → should batch-delegate research
- **>15 terminal calls** → iterative build without delegation
- **Browser tool used without delegation** → heavy schema overhead in orchestrator

The full audit query is in `references/session-audit-query.md`.

### 2. Model Routing (Manifest)

Manifest is a self-hosted smart model router. Install:

```bash
bash <(curl -sSL https://raw.githubusercontent.com/mnfst/manifest/main/docker/install.sh) --yes
```

**Create admin account and agent** via browser at http://localhost:2099. Then configure Hermes:

```bash
hermes config set model.provider custom
hermes config set model.base_url http://localhost:2099/v1
hermes config set model.api_key <manifest-api-key>
hermes config set model.default auto
```

**Routing table** (configure via Manifest dashboard at `/agents/<name>/routing`):

| Tier | Primary | Fallback |
|------|---------|----------|
| Simple | DeepSeek V4 Pro | DeepSeek V4 Pro |
| Standard | DeepSeek V4 Pro | DeepSeek V4 Pro |
| Complex | DeepSeek V4 Pro | DeepSeek V4 Pro |
| Reasoning | DeepSeek V4 Pro | DeepSeek V4 Pro → Opus (on failure only) |

**Opus is NOT a complexity tier.** Expose it only as an explicit custom route (user triggers deliberately). The custom route must bypass Manifest's downgrade-to-cheaper behavior.

**WARNING — Hermes v0.15.1 delegation bug:** `delegate_task` subagents do NOT route through Manifest. Setting `delegation.base_url`/`api_key` to the Manifest proxy does NOT work — child agents resolve to `api.deepseek.com` regardless and send the Manifest key → 401. Setting `delegation.provider` to `custom:manifest-vision` or `openrouter` also fails identically. This is a transport bug, not a config issue.

**If you have a direct DeepSeek API key**, subagents CAN route directly:
```bash
hermes config set delegation.model deepseek-v4-pro
hermes config set delegation.provider deepseek
hermes config set delegation.base_url https://api.deepseek.com/v1
hermes config set delegation.api_key_env DEEPSEEK_API_KEY
```

**If you don't**, delegation is broken. Workarounds:
- Use `execute_code` for sub-tasks (runs in parent process, reaches Manifest correctly)
- Get a DeepSeek API key and configure direct routing above
- Await Hermes fix for delegation + Manifest compatibility

If the dashboard is unreliable (skeleton loaders, 404s on routing endpoints), use the **browser console API approach** — much faster and works around UI bugs. See `references/manifest-routing-config.md` for the full dashboard walkthrough and `references/manifest-api-endpoints.md` for the programmatic approach.

### 3. Delegate-First Tool Access

Disable the heaviest toolsets on the orchestrator profile. Each disabled toolset saves ~800-1000 tokens/turn in schema overhead.

```bash
# Disable heaviest toolsets (takes effect next session)
hermes tools disable browser       # 13 tools, heaviest
hermes tools disable vision        # if not needed inline
hermes tools disable image_gen     # if not needed inline
```

Replace with SOUL.md instructions telling the agent to delegate:

```markdown
# Token Discipline — Delegate-First Rules
1. >50 LOC or tool output → delegate to subagent
2. Never carry raw details — verify summaries, not internals
3. Batch research: 3+ lookups → parallel delegate_task
4. session_search before re-discovery
5. Browser work → delegate_task(toolsets=['browser'])
6. Heavy MCP → executor profile or delegation
7. File ops: search_files/read_file/patch, not ls/cat/sed
```

**Important:** Tool changes take effect on next session (`/reset`). Current session retains loaded tools. Disabled toolsets remain available to delegated subagents.

### 4. Cheap Executor Profile

Create a lean profile for background work (cron jobs, kanban workers, delegated implementation):

```bash
hermes profile create executor --clone-from default

# Pin to cheap model directly (no Manifest overhead)
hermes --profile executor config set model.default deepseek-v4-pro
hermes --profile executor config set model.provider deepseek
hermes --profile executor config set model.base_url https://api.deepseek.com/v1
hermes --profile executor config set model.api_key_env DEEPSEEK_API_KEY

# Disable heavy toolsets
hermes --profile executor tools disable browser
hermes --profile executor tools disable vision
hermes --profile executor tools disable image_gen
hermes --profile executor tools disable tts
hermes --profile executor tools disable messaging
hermes --profile executor tools disable homeassistant
hermes --profile executor tools disable computer_use
```

Write a minimal SOUL.md:

```markdown
You are a background executor — a leaf worker that runs cheaply on DeepSeek V4 Pro
with minimal tools. Do the work, return the result, do not chat. Be concise.
Prefer built-in tools over MCP where possible.
```

### 5. Daily Self-Audit Cron

Set up a cron job that scans for violation patterns daily:

```python
cronjob(
    action="create",
    name="Daily Delegation Audit",
    schedule="0 9 * * *",
    profile="executor",              # cheap model, minimal tools
    model={"model": "deepseek-v4-pro", "provider": "deepseek"},
    enabled_toolsets=["terminal", "file", "session_search"],
    skills=["hermes-agent"],
    prompt="""SELF-AUDIT: Scan session DB for last 24 hours. Flag:
1. >100K input tokens + zero delegate_task
2. >8 web_search + zero delegation
3. >15 terminal calls without delegation
Write violations to /root/.hermes/pending-fixes.md.
Append summary to /root/.hermes/audit-log.md.
DO NOT modify config or session files."""
)
```

### 6. Static Knowledge (CONTEXT.md)

For each active project directory, create CONTEXT.md so the agent stops re-exploring:

```markdown
# /root — System Context
## Active Services
- Manifest (self-hosted model router) — Docker, port 2099
- Hermes Agent — installed at /usr/local/lib/hermes-agent
## Profiles
- default — main, routes through Manifest
- executor — lean worker, DeepSeek direct, minimal tools
## Key Conventions
- Python: python3 (no pip), PEP 668 enforced
- Delegation: prefer delegate_task over in-process for >50 LOC
```

Where project docs exist (Obsidian vault, wiki), read those instead of re-discovering via terminal calls. Load the `obsidian` skill before reading vault content.

## Pitfalls

- **Browser tools disabled breaks browser-only workflows.** The SOUL.md delegation instruction must be present so the agent knows to delegate. Test with a trivial browser task after disabling.
- **Manifest dashboard may have loading issues.** The routing page fetches from `/api/v1/routing/<agent>/` endpoints. If these 404, try `docker compose pull && docker compose up -d` to get latest fixes. The API key shown in Settings is the one that works. When the UI is unreliable, configure via browser console API calls (see `references/manifest-api-endpoints.md`).
- **Manifest dashboard session expires quickly.** The browser login session times out after a few minutes of inactivity. When configuring via browser console, batch all API calls into one async block before the session dies.
- **Delegation model must have API key.** Set `delegation.api_key_env` to reference the env var (DEEPSEEK_API_KEY), not hardcode the key in config.yaml.
- **Tool changes need /reset.** Disabled toolsets only take effect on next session. Current session retains all tools loaded at startup.
- **Don't disable delegation toolset.** The orchestrator needs delegate_task to offload work. Disabling it traps everything in-process.
- **Executor profile needs its own .env.** Profiles don't inherit .env from default. Either copy it or ensure the required env vars are set globally.
- **Secret redaction blocks API key access.** Hermes's `security.redact_secrets` redacts keys from ALL tool output (terminal, read_file, execute_code). Workaround: write key to temp file via execute_code, then hex-dump with `xxd /tmp/key.txt` and decode the hex bytes manually. See `references/manifest-routing-config.md` for the full recipe. Clean up temp files after.

## References

- `references/session-audit-query.md` — Full SQL query for session token audit
- `references/manifest-routing-config.md` — Manifest dashboard setup walkthrough with screenshots and routing table
- `references/manifest-api-endpoints.md` — Programmatic Manifest configuration via browser console (API endpoint map, provider/tier/header-tier management)
