# Manifest API Endpoints — Programmatic Configuration

When the Manifest dashboard has loading issues or you need speed, configure via the browser console using `fetch()`. All endpoints are scoped to `/api/v1/routing/:agentName/`.

## API Route Discovery

To discover available routes when endpoints 404:

```bash
docker logs mnfst-manifest-1 2>&1 | grep "Mapped" | grep -i "tier\|provider"
```

## Provider Management

### List providers
```
GET /api/v1/routing/:agentName/providers
```

### Add a provider (API key)
```
POST /api/v1/routing/:agentName/providers
Body: {"provider": "deepseek", "apiKey": "sk-..."}
```

Example via browser console:
```javascript
const r = await fetch('/api/v1/routing/hermes-default/providers', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({provider: 'anthropic', apiKey: 'sk-ant-...'})
});
// 201 Created on success
```

### Remove a provider
```
DELETE /api/v1/routing/:agentName/providers/:provider
```

### Refresh provider models
```
POST /api/v1/routing/:agentName/providers/:provider/refresh-models
```

## Complexity Tier Management

### List tiers
```
GET /api/v1/routing/:agentName/tiers
```

Returns array of tier objects with `tier` (simple|standard|complex|reasoning|default), `auto_assigned_route`, `override_route`, and tier `id`.

### Update a tier (set model override)
```
PUT /api/v1/routing/:agentName/tiers/:tier
Body: {"provider": "deepseek", "model": "deepseek-v4-pro", "authType": "api_key"}
```

Example — switch all tiers to DeepSeek V4 Pro:
```javascript
(async () => {
  for (const tier of ['simple','standard','complex','reasoning','default']) {
    await fetch(`/api/v1/routing/hermes-default/tiers/${tier}`, {
      method: 'PUT',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({provider:'deepseek', model:'deepseek-v4-pro', authType:'api_key'})
    });
  }
  location.reload();
})();
```

### Reset all tiers to auto-assigned
```
POST /api/v1/routing/:agentName/tiers/reset-all
```

### Remove a tier override
```
DELETE /api/v1/routing/:agentName/tiers/:tier
```

### Manage tier fallbacks
```
GET    /api/v1/routing/:agentName/tiers/:tier/fallbacks
PUT    /api/v1/routing/:agentName/tiers/:tier/fallbacks
DELETE /api/v1/routing/:agentName/tiers/:tier/fallbacks
```

## Custom Header Tiers (for explicit model routing)

Header tiers allow forcing a specific model via HTTP headers, bypassing complexity scoring. Use this for Opus final-pass routes.

### Create a header tier
```
POST /api/v1/routing/:agentName/header-tiers
Body: {
  "name": "Opus Final Pass",
  "header_key": "x-manifest-tier",
  "header_value": "opus",
  "provider": "anthropic",
  "model": "claude-sonnet-4",
  "authType": "api_key",
  "badge_color": "purple"    // optional, any valid color name
}
```

Required fields: `name`, `header_key`, `header_value`. Provider/model/authType define the route.

### Set model override on a header tier
```
PUT /api/v1/routing/:agentName/header-tiers/:id/override
Body: {"provider": "anthropic", "model": "claude-sonnet-4", "authType": "api_key"}
```

### List header tiers
```
GET /api/v1/routing/:agentName/header-tiers
```

### Toggle, reorder, delete
```
PATCH  /api/v1/routing/:agentName/header-tiers/:id/toggle
POST   /api/v1/routing/:agentName/header-tiers/reorder
DELETE /api/v1/routing/:agentName/header-tiers/:id
```

## Session Expiry

The dashboard session expires quickly (~minutes of inactivity). The agent API key (`mnfst_...`) is for `/v1/chat/completions` only — NOT for the REST API. All browser console calls must be made while logged into the dashboard (session cookies are sent automatically by `fetch()` from the same origin).

## Badge Colors (for header tiers)

Valid values: slate, gray, zinc, stone, red, orange, amber, yellow, lime, green, emerald, teal, cyan, sky, blue, indigo, violet, purple, fuchsia, pink, rose, coral, brown, navy.
