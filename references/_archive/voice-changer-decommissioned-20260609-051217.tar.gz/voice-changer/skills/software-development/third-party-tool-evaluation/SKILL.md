---
name: third-party-tool-evaluation
description: "Review-before-install: evaluate third-party AI tools/skills/repos, cherry-pick over bulk install. Use when the user shares a GitHub repo, skill, plugin, MCP server, or external tool and asks to review/adopt/install it."
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [evaluation, review, cherry-pick, supply-chain, security, footprint]
    related_skills: [requesting-code-review, token-optimization, knowledge-store]
---

# Third-Party Tool / Skill / Repo Evaluation

When the user points you at an external repo, skill, plugin, MCP server, or tool
and asks to "review", "look at", "adopt", or "install" it — DO NOT clone-and-install
by default. Run a structured review, then **cherry-pick the durable ideas over bulk
installing the artifact.** This is the user's standing preference (review-before-install,
minimal footprint, consolidation over stacking).

## When to Use

- User shares a GitHub URL and says "let's review this" / "should I install this?"
- User asks to adopt a third-party skill, plugin, MCP server, agent framework, or CLI tool
- You surface a candidate tool yourself and are tempted to install it

**Default posture: skeptical adopter, not eager installer.** The deliverable is a
verdict + a cherry-pick, not a running clone.

## The 5-Lens Review (run all five, lead with the verdict)

State your verdict UP FRONT (install / cherry-pick / skip), then justify with these lenses:

1. **What it is** — one tight paragraph: what it does, maturity signals (stars, last
   commit, commit count, author, license, "vibe-coded / unmaintained" disclaimers).
   A 5-commit "Saturday hack the author won't support" is a cherry-pick candidate at best.

2. **Security / supply-chain scan** — read the ACTUAL code of anything that runs:
   install scripts, hooks, activators, entrypoints. Look for network calls,
   file writes outside scope, eval/exec, exfiltration, credential reads. Pull raw
   files (e.g. raw.githubusercontent.com) and read them — don't trust the README.
   Distinguish *technical* risk (malicious code) from *behavioral* risk (a hook that
   nags every prompt, prompt-steering, token bloat). Both are real costs.

3. **Overlap** — does Hermes already do this natively? Map the artifact's features
   1:1 against existing machinery (curator, skill system, delegate_task, Manifest
   routing, memory, cron). Heavy overlap = installing it STACKS a redundant system.
   This is usually the dealbreaker — name the specific native equivalent for each feature.

4. **Env-compat** — would it even run here? Vanilla-Claude-Code paths
   (`~/.claude/skills`, `UserPromptSubmit` hooks, the `Skill()` tool) ≠ Hermes paths
   (`~/.hermes/skills`, `skill_manage`, curator). Direct-OpenRouter calls bypass
   Manifest tiering/cost-routing. 2023-era prompt-lib/OpenAI-completion plumbing won't
   slot into the current stack. A straight clone often does nothing useful or fights setup.

5. **Footprint / cost** — standing service = standing attack surface + standing cost.
   N-model fan-outs are N× tokens. Extra API keys, extra ports, extra processes.
   Weigh against the user's minimal-footprint + Manifest cost-discipline preferences.

## Cherry-Pick, Don't Bulk-Install

The valuable output is almost always the **pattern/technique**, not the artifact.
Extract the 1-3 durable ideas and map them onto EXISTING Hermes machinery:

- Skill-extraction loop → `skill_manage` + curator (already have it)
- Self-critique loop → `verification-before-completion` + a fresh subagent for the critique
- Multi-model council → `delegate_task(tasks=[...])` parallel subagents, orchestrator synthesizes
- Retrieval-optimized descriptions → bake exact error strings into skill descriptions

## If the Verdict IS Install — Install Natively, Bypass the Upstream CLI

When the user explicitly chooses to install a skill pack (not cherry-pick), do NOT run
the upstream installer. Most skill-pack installers (`npx skills add <repo>`, vanilla
Claude Code tooling) target `~/.claude/skills` and won't wire into Hermes. Instead:

1. **Check frontmatter compatibility.** Hermes skills need YAML frontmatter with a `name:`
   field and `---` delimiters. Some third-party `SKILL.md` files have this shape and drop in
   natively. **If frontmatter is MISSING** (the file starts with `# Title` directly —
   common in large skill packs like ui-ux-pro-max), generate a minimal block and prepend it:
   ```python
   f"---\nname: {slug}\ndescription: \"{one_liner}\"\nversion: 1.0.0\nlicense: MIT\ncategory: {cat}\n---\n\n"
   ```
   Then verify with `head -3` that `---` and `name:` appear on the first two lines.
2. **Pull files directly, off-context.** Use the GitHub git-trees API to enumerate paths,
   then curl each `SKILL.md` into a category dir under `~/.hermes/skills/<category>/<skill>/`.
   Do this in ONE terminal loop, not file-by-file through the agent — keeps raw content out
   of your context window:
   ```bash
   BASE="https://raw.githubusercontent.com/<owner>/<repo>/main/skills"
   for s in skill-a skill-b ...; do mkdir -p "$s"; \
     curl -s -o "$s/SKILL.md" -w "%{http_code}\n" "$BASE/$s/SKILL.md"; done
   ```
   Grab any sibling support files the skill references (e.g. a `DESIGN.md`) too.
2a. **Add YAML frontmatter if missing.** Many upstream skills (e.g. the ui-ux-pro-max set) ship bare `# Title` headers with no `---` block. Hermes's `skills_list` + `skill_view` require a `name:` in YAML frontmatter for discovery — a file on disk without it is invisible. Before the verify gates, check each file: `grep -m1 '^---\\|^name:' <skill>/SKILL.md`. If absent, prepend a minimal block. Example (run in the target category directory):\n   ```bash\n   python3 -c \"\n   import os\n   skills = {'name-one':'short desc','name-two':'short desc'}\n   for name,desc in skills.items():\n       path = os.path.join(name,'SKILL.md')\n       with open(path) as f: content = f.read()\n       fm = f'---\\nname: {name}\\ndescription: \\\"{desc}\\\"\\nversion: 1.0.0\\n---\\n\\n'\n       with open(path,'w') as f: f.write(fm + content)\n   print('frontmatter added')\n   \"\n   ```\n   Verify frontmatter integrity after write: `head -4 <skill>/SKILL.md` must show `---`, `name: ...`, a description line, and `---`.\n3. **Verify, three gates:** (a) every download returned HTTP 200; (b) frontmatter intact —
   `grep -m1 '^name:'` each file gives a unique non-empty name and first line is `---`;
   (c) Hermes discovers them — `skills_list(category=...)` returns the expected count with
   real descriptions. A file on disk that `skills_list` doesn't surface is NOT installed.
4. **Watch for auto-steering files.** Repos may ship `.github/copilot-instructions.md` or
   similar that auto-inject behavior into any agent pointed at the clone. Copy ONLY the
   `SKILL.md` files, never the repo's agent-instruction files.
5. **README counts lie.** "16 skills" / "Shell 100%" often double-count variants or mislabel
   a tiny lookup script. Trust the git tree, not the marketing.
6. **Log the flip.** Installs are rarer than cherry-picks — record the row in
   `references/evaluated-tools-log.md` with verdict **Install**, note the native path used,
   and the one-line removal recipe (`rm -rf ~/.hermes/skills/<category>/`).

## Document the Cherry-Pick (don't install)

Capture the extracted nuggets as a durable note so the value survives without footprint.
House it under the umbrella that governs the pattern's domain, or in
`~/.hermes/references/<topic>.md` for cross-cutting patterns. Every such note MUST state:
1. **Source** (repo + license + date) and that the upstream artifact was **NOT installed**, with why.
2. The extracted nugget(s), **mapped onto Hermes tooling** (not the upstream's API).

See `references/cherry-pick-note-template.md` for the basic shape (1-2 nugget repos),
`references/rich-cherry-pick-format.md` for multi-concept repos with mixed verdicts, and
`references/evaluated-tools-log.md` for the running log of what's been reviewed and the verdict.

## Verify Before Relying on a Cherry-Pick

If the cherry-picked pattern depends on a Hermes capability, VERIFY that capability
actually works before telling the user the pattern is usable. Example: a council
pattern rides on `delegate_task` routing through Manifest — run a 1-subagent probe
first. A documented pattern on top of broken transport is a trap. (Earliest-fit:
this is the `verification-before-completion` discipline applied to adoption.)

## Pitfalls

- **Trusting the README over the code.** Always read the actual install script / hook.
- **Bulk-installing because it has 20k stars.** Stars ≠ fit. Karpathy's own llm-council
  is 5 commits, unmaintained, and explicitly "for inspiration." Cherry-pick it.
- **Stacking a redundant loop.** If Hermes already extracts skills / refines / routes,
  a second system fighting the first is worse than nothing.
- **Forgetting the frontmatter repair step.** Checking "does it have YAML frontmatter?" without providing what to do when the answer is "no" leaves a silent gap — the files land on disk but Hermes never discovers them. Always prepend a minimal block if it's missing. A vanilla-Claude-Code skill with `~/.claude` paths
  and `UserPromptSubmit` hooks will not work in Hermes as-shipped.
- **Documenting a pattern on broken transport.** Verify the dependency before declaring usable.
- **Writing the note as a mirror of upstream docs.** Concise, Hermes-mapped, value-focused — not a copy.
