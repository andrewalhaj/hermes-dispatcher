---
name: home-assistant-dashboard
description: "Delegate the full HA dashboard build-validate-restart loop to a subagent. Use when building, modifying, or iterating on a Home Assistant dashboard (ha-fusion or native Lovelace) — especially when the task involves editing YAML, restarting HA, and visually verifying the result. Encapsulates the cyclically expensive pattern: read → patch → validate → restart → verify."
version: 1.0.0
author: Hermes Agent (from token-waste audit fix)
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [home-assistant, dashboard, delegation, token-optimization]
    load_when:
      - "building or modifying a Home Assistant dashboard"
      - "editing ha-fusion dashboard.yaml or custom_style.css"
      - "any task that involves restarting HA for visual verification"
      - "user says 'change the dashboard' or 'update the UI'"
---

# Home Assistant Dashboard — Delegate-First Skill

**USE THIS SKILL BEFORE DOING DASHBOARD WORK IN THE MAIN LOOP.**

Building or modifying a Home Assistant dashboard in the main agent loop is the single most expensive token-waste pattern observed across all audited sessions. The cycle is: read file → patch YAML → restart HA → visually verify → repeat. Each cycle is 5-6 tool calls. Multiple cycles done inline produce massive context bloat (745K+ tokens). The fix is simple: **delegate the entire build-validate-restart loop to a subagent.**

## When to delegate

**Hard triggers (delegate immediately):**
- The task involves editing `dashboard.yaml`, `configuration.yaml`, `.storage/lovelace.*`, or `custom_style.css` for ha-fusion
- The task will require restarting HA or ha-fusion
- The task involves visual/UI iteration (>2 expected changes)
- The user says "build a dashboard," "update the dashboard," "fix the UI," "add a tile/card," "consolidate buttons into panels," etc.
- The task follows the pattern: read config → edit → validate → restart → verify

**Auto-delegate threshold:** if a session accumulates >3 HA restarts or >2 vision_analyze/visual-verification calls for dashboard work, delegate the remainder immediately.

**Exception — single CSS hot-edit:** a one-line CSS change that hot-reloads (no restart) is fine inline. Still back up `.prev` first.

## How to delegate

### ha-fusion dashboard work

```
delegate_task(
    goal="Modify the ha-fusion dashboard at /root/ha-fusion/data/dashboard.yaml on host 178.156.246.115 per these requirements: [specific changes]. Validate YAML after editing. Restart ha-fusion container. Verify the dashboard serves HTTP 200 and the Tailscale bind 100.119.118.54:5050 is preserved. Return a structured summary: what was changed, verification results, and any warnings.",
    context="""HA host: 178.156.246.115 (SSH root@, key ~/.ssh/id_ed25519)
Dashboard YAML: /root/ha-fusion/data/dashboard.yaml
CSS: /root/ha-fusion/data/custom_style.css
Container: ha-fusion (restart needed for YAML changes, but NOT for CSS changes)
TAILSCALE BIND IS SACROSANCT: -p 100.119.118.54:5050:5050 — NEVER 0.0.0.0
Backup before editing: cp file.yaml file.yaml.prev
Validate: python3 -c "import yaml; yaml.safe_load(open('file.yaml'))"
Restart: docker restart ha-fusion
Verify: curl -o /dev/null -w '%{http_code}' http://100.119.118.54:5050/
Bind check: ss -tlnp | grep 5050 must show 100.119.118.54 NOT 0.0.0.0

The entity inventory is at ~/.hermes/references/ha-handoff/02-entity-inventory.md.
Canonical custom_panel schema: ~/.hermes/references/ha-handoff/references/custom-panel-schema.md.

NEVER invent fields (primary_row_id), NEVER place a panel AS a view.
For CSS-only changes, no restart needed — just scp the file.""",
    toolsets=["terminal", "file"]
)
```

### Native HA Lovelace dashboard work

```
delegate_task(
    goal="Build/modify the HA Lovelace dashboard in .storage/lovelace.<id> on host 178.156.246.115 with these requirements: [specific changes]. Validate JSON, restart HA if needed, verify via curl or websocket. Return a structured summary.",
    context="""HA host: 178.156.246.115 (SSH root@)
Config dir: /root/homeassistant/config
HA container: homeassistant (--network host)
Dashboard storage key MUST match the id in .storage/lovelace_dashboards, NOT url_path.
Restart: docker restart homeassistant
Verify: curl -H 'Authorization: Bearer <token>' http://localhost:8123/api/states""",
    toolsets=["terminal", "file"]
)
```

## Subagent instructions

The subagent must:
1. Back up any file before editing (`.prev` with timestamp)
2. Validate YAML/JSON after every edit
3. Preserve the Tailscale bind on any container recreate (`-p 100.119.118.54:5050:5050`)
4. Return a structured summary: what was changed, file paths, verification results, any errors or warnings
5. NEVER fabricate visual confirmation — the subagent cannot screenshot the dashboard

## Verification gates (subagent must report)

- YAML/JSON valid: yes/no
- Container(s) running: yes/no
- Tailscale bind correct (100.119.118.54): yes/no
- Dashboard serves HTTP 200: yes/no
- Visual confirmation: UNVERIFIED (Tailscale-only, not screenshot-able)

## Anti-patterns (what this skill prevents)

- Reading dashboard YAML in the main loop (bloats context)
- Patching + restarting + verifying cyclically in the main loop
- 6 vision_analyze calls for iterative UI debugging in the main loop
- 103 terminal calls for what should be one delegated task
- Keeping accumulated tool output from 6 HA restarts in context
