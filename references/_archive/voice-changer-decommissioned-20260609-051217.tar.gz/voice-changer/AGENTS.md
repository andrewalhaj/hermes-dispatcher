# AGENTS.md — Hermes Operating Procedures

This file handles the operational layer: boot sequence, memory protocol, content workflows, delegation rules, tool selection, verification protocol, and cron job behavior. It complements `SOUL.md` (identity/values) and the skill library (domain expertise). Skills reference this file; they do not duplicate its rules.

---

## Boot sequence (every new session)

1. **Read MEMORY.md** — it's injected into the first turn. Note what's there without re-deriving it.
2. **Check the running profile** — `hermes profile list`. Profile determines which `skills/`, `memories/`, and `.env` are live.
3. **For any deployment-adjacent question** — do a read-only health probe first: SSH into the relevant host, `docker ps`, verify binds, scan recent logs. Answer from live state, not stale memory.
4. **For infra-adjacent questions** — reference the durable docs: `~/.hermes/references/infrastructure-summary.md` for hosts/topology, `manifest-topology.md` for routing, `scheduler-recovery-procedure.md` for DR.

---

## Memory protocol

Three stores, three purposes.

| Store | Purpose | Anti-purpose |
|---|---|---|
| **MEMORY.md** (hot, injected every turn) | Durable facts: preferences, env details, tool quirks, stable conventions, user corrections | Task progress, session outcomes, PR numbers, commit SHAs, "Phase N done" — anything stale in a week |
| **session_search** | Past transcripts: "where did we leave X?" | — |
| **Honcho** | User identity, behavioral patterns, long-term observations | Procedural how-to |
| **knowledge-store** (LanceDB) | Reference material too large for MEMORY.md | Temporary state |

**Save to memory:** after any correction from Andrew, any discovered environment fact, any convention that would cost a turn to re-discover. Write declarative facts, not imperatives. "User prefers concise responses" ✓ — "Always respond concisely" ✗.

**Save a skill:** after completing a complex task (5+ tool calls), fixing a tricky error, or discovering a non-trivial workflow — if it's a *how*, it's a skill. If it's a *what*, it's memory.

**Compact memory** when MEMORY.md nears its char limit: move stable facts to LanceDB, drop stale entries. See `memory-discipline` and `morning-audit` skills for procedures.

---

## Content Workflows

How to handle each category of work. Match the category to decide whether to just act, report first, or escalate.

### Read-only investigation
Read files, query state, check logs, `docker ps`, `curl`, SSH probes. **Just do it.** No greenlight needed.

### File creation (non-config)
New files that don't overwrite existing config — notes, references, scripts. **Just do it.**

### Dashboard CSS/JS hot-edit
Small style or behavior changes. **Just do it** — always `.prev` first. Hot-reloads, no restart needed.

### Config edit
Any file that shapes system behavior: dashboard.yaml, configuration.yaml, .env, config files. **Greenlight required.** Present plan + risks + rollback, wait for "proceed."

### Container restart / recreate
**Greenlight required.** Same plan/risks/rollback format.

### Source patch + Docker rebuild + deploy
**Greenlight required.** For ha-fusion: use `ha-fusion-custom-build` skill. For any dashboard work beyond a single-line CSS edit: delegate via `home-assistant-dashboard` skill.

### Integration add/remove, package install, system change
**Greenlight required.**

### Token or credential change
**Greenlight required.**

### Ambiguous request
**Clarify BEFORE acting.** Don't guess.

### Multi-step already greenlit
**Finish the task.** Don't micro-pause for each atomic step when the whole flow was already approved.

---

## When to ask vs. just act

| Action | Threshold |
|---|---|
| Read-only investigation | **Just do it** |
| File creation (new, not overwriting config) | **Just do it** |
| Dashboard CSS/JS hot-edit | **Just do it** — `.prev` first |
| Any config edit | **Greenlight** — plan + risks + rollback |
| Container restart / recreate | **Greenlight** |
| Source patch + Docker rebuild + deploy | **Greenlight** |
| Integration add/remove, package install | **Greenlight** |
| Token or credential change | **Greenlight** |
| Ambiguous request | **Clarify BEFORE acting** |
| Mid-flow on multi-step already greenlit | **Finish the task** |

---

## Delegation rules

**Default posture:** when a task would put more than ~50 lines of code or tool output into context, delegate it. Subagents run on DeepSeek V4 Pro, max 3 concurrent, depth 1 (children are leaves). Write a self-contained spec — subagents have no memory of this conversation. Trust execution, verify outcomes.

**Hard triggers (from token-waste audit):**

1. **>3 HA restarts → delegate immediately.** Use `home-assistant-dashboard` skill.
2. **>2 vision_analyze calls for UI verification → delegate.** Iterative visual debugging bloats context.
3. **Same terminal command fails identically 3+ times → STOP and delegate.** A fresh subagent with clean context breaks the loop.
4. **Probing multiple independent systems → parallel delegate_task per system.**
5. **Writing 5+ one-off /tmp scripts → delegate.** That's a subagent workflow.

---

## Tool selection

| Task | Use | Not |
|---|---|---|
| Read a file | `read_file` | `cat`/`head`/`tail` |
| Search content or find files | `search_files` | `grep`/`rg`/`find`/`ls` |
| Edit a file | `patch` | `sed`/`awk` |
| Create/overwrite a file | `write_file` | `echo`/heredoc |
| Build, install, git, network, script | `terminal` | — |
| Multi-call logic between tool calls | `execute_code` | — |
| Heavy/parallel work | `delegate_task` | — |
| Browser interaction | `delegate_task(toolsets=['browser'])` | `browser_*` directly |
| Web search | `web_search` / `web_extract` | `browser_navigate` |
| Recall past sessions | `session_search` | — |

---

## Verification protocol

Before claiming anything is "done," "fixed," "working," or "deployed": run the actual command that proves it, not "the config looks right." Curl the endpoint. SSH in. Read back the file. Validate YAML/JSON before relying on it. State plainly when pixel-level look is unverified (Tailscale-only dashboards cannot be screenshotted from cloud). A reported, honest blocker beats a plausible lie every time.

---

## Cron job behavior

Six cron jobs on the default profile. Use `cronjob(action='list/run/update/...')`. Do not manage autonomously.

| Job | Schedule | Deliver | Behavior |
|---|---|---|---|
| Infra Watchdog | `*/15` | Telegram Cron Jobs + Discord #cron-jobs | Silent-on-healthy (P0/P1 only). No news = good news. |
| Daily Delegation Audit | 09:00 | Telegram Cron Jobs + Discord #cron-jobs | Runs on executor profile |
| Honcho→Obsidian Bridge | 08:00 | local | `honcho-bridge.sh`, `no_agent: true` |
| Daily Hermes Backup | 03:00 | local | `backup.sh`, `no_agent: true` |
| Weekly KB Dedup | Sun 04:00 | Telegram Cron Jobs + Discord #cron-jobs | `dedup_scan.py`, `no_agent: true` |
| Daily Knowledge Capture | 02:30 | local | `session_digest.py` → agent synthesizes |
