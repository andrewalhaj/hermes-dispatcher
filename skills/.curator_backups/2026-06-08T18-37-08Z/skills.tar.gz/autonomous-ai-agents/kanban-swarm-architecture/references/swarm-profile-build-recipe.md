# Swarm profile build recipe (verified live, Hermes v0.16.0, June 2026)

The exact sequence that stood up a 5-profile swarm pod end-to-end. Reproduce with
modifications. All `profile create` / `config set` / SOUL writes are GATED — present plan +
rollback, get greenlight, back up first.

## Roster built

| Profile | Clone from | Model | Role |
|---|---|---|---|
| swarm-worker-a/b/c | executor | deepseek-v4-pro | parallel workers (a=research, b=architecture, c=implementation) — distinct descriptions for decomposer routing |
| swarm-verifier | default | claude-sonnet-4-6 | skeptical review gate (stronger model on purpose) |
| swarm-synthesizer | executor | deepseek-v4-pro | assembler |

3 distinct worker profiles (NOT one spawned 3×) → each gets its own `state.db` → **no SQLite
write-contention** under concurrency. At 30GB free the cost of 2 extra profiles is noise.
(If you ever DID run one worker profile N×, the open risk is N processes sharing one state.db
— "database is locked". Distinct profiles sidestep it by construction.)

## Step 1 — create (native tool, --description drives decomposer routing)

```bash
hermes profile create swarm-worker-a --clone-from executor --no-alias \
  --description "Parallel swarm worker — research & investigation. Executes one decomposed subtask in an isolated workspace, writes findings to the blackboard. Fast/cheap (DeepSeek). Does not verify or synthesize."
# ...worker-b (architecture & design), worker-c (implementation & detail) — same shape
hermes profile create swarm-verifier --clone-from default --no-alias \
  --description "Skeptical verification gate. Reviews combined worker output; blocks with comments if incomplete/wrong; only passes clean work. Does NOT do the work or synthesize."
hermes profile create swarm-synthesizer --clone-from executor --no-alias \
  --description "Synthesizer. Wakes only after the verifier passes. Assembles approved output into the final deliverable. Composes; does not re-research."
```
Verify: `hermes profile list | grep swarm-` → check models (workers/synth = deepseek-v4-pro,
verifier = claude-sonnet-4-6).

## Step 2 — scrub the inherited plaintext key (DeepSeek clones only)

`config.yaml` cannot be edited by `patch`/`write_file` (security write-guard refuses). Use
the CLI, `--profile` scoped:
```bash
for p in swarm-worker-a swarm-worker-b swarm-worker-c swarm-synthesizer; do
  hermes --profile "$p" config set model.api_key ""
done
```
Safe because `api_key_env: DEEPSEEK_API_KEY` + each `.env` has the key → env fallback covers
auth. **Do NOT touch swarm-verifier** — its `default`-inherited Anthropic/OAuth auth is the
real working auth, not a vestigial key.

## Step 3 — role SOULs (gated write_file, .bak first)

Workers keep the lean inherited `executor` SOUL (generic background-executor text — fine
as-is). Only rewrite the two that need a distinct posture:
- **swarm-verifier/SOUL.md** — adversarial gate: read all worker output, check claims are
  supported, `kanban_block` with *specific actionable* comments naming the exact defect
  ("Worker B's failover plan has no split-brain handling for EU"), never vague ("needs more
  detail"); does NOT do the work or synthesize; "looks fine" is not verification.
- **swarm-synthesizer/SOUL.md** — assembler: read verifier-approved output, compose into one
  coherent deliverable, resolve overlaps, do NOT re-research or re-verify or invent new claims.

## Step 4 — verify the whole build

```bash
hermes profile list | grep swarm-                    # 5 exist, correct models
# keys scrubbed on 4 deepseek profiles, env fallback present:
for p in swarm-worker-a swarm-worker-b swarm-worker-c swarm-synthesizer; do
  grep -E '^\s+api_key:' ~/.hermes/profiles/$p/config.yaml   # empty
  grep -c DEEPSEEK_API_KEY ~/.hermes/profiles/$p/.env        # 1
done
hermes profile describe swarm-worker-a               # description registered for routing
python3 -c "import yaml;yaml.safe_load(open('<each>/config.yaml'))"  # parses
```

## Rollback

`hermes profile delete swarm-worker-a swarm-worker-b swarm-worker-c swarm-verifier swarm-synthesizer`
— clean, zero impact on existing profiles. SOUL edits have `.bak-<ts>`.

## The manual-dispatch config that pairs with this (also via `hermes config set`)

```bash
hermes config set delegation.max_concurrent_children 8   # 8 only if multi-swarm/fleet confirmed; else 6
hermes config set kanban.dispatch_in_gateway false       # MASTER SWITCH: kills autonomous tick
hermes config set kanban.auto_decompose false            # no auto fan-out
hermes config set kanban.auto_decompose_per_tick 8       # inert while dispatch off; ready if re-enabled
```
With `dispatch_in_gateway: false`, nothing spawns until a human runs `hermes kanban dispatch`
— this is the cost governor AND cron isolation. The `patch` tool will refuse config.yaml; this
CLI path is the sanctioned one and writes are visible/verifiable via read-back.
