# Detached update-runner template

Full template for the detached system-level runner (PITFALL 4/5). Save under
`~/.hermes/scripts/`, launch with:
`systemd-run --unit=hermes-update-$(date +%s) --collect bash <script>`

Key conventions:
- Read the bot token at RUNTIME from `.env` inside the script (never inline in a
  terminal command — the credential filter truncates it to ~14 chars). A script
  file written via write_file is left intact.
- `notify()` posts to Telegram Bot API and never fails the script if unreachable.
- The update step is FATAL-abort; everything else is best-effort with a report.
- Set `HOME=/root` before calling install.sh (it uses `set -u`; unbound HOME
  in a systemd unit → `HOME: unbound variable`).

```bash
#!/bin/bash
set -uo pipefail
HERMES="/usr/local/lib/hermes-agent/venv/bin/hermes"
ENV_FILE="/root/.hermes/.env"
CLAUDE_AUTH_DIR="/root/hermes-claude-auth"
CHAT_ID="<your-telegram-chat-or-channel-id>"
TS="$(date +%Y%m%d-%H%M%S)"
LOGFILE="/root/.hermes/logs/update-runner-${TS}.log"
SNAP="pre-update-$(date +%Y-%m)"
RESTART_VOICE_CHANGER="${RESTART_VOICE_CHANGER:-no}"   # skip crash-loopers
mkdir -p /root/.hermes/logs

TOKEN="$(grep -E '^TELEGRAM_BOT_TOKEN=' "$ENV_FILE" | head -1 | cut -d= -f2- | tr -d '\r\n')"
log()    { echo "[$(date +%H:%M:%S)] $*" | tee -a "$LOGFILE"; }
notify() { log "$1"; [ -n "$TOKEN" ] && curl -s --max-time 20 \
  "https://api.telegram.org/bot${TOKEN}/sendMessage" \
  --data-urlencode "chat_id=${CHAT_ID}" --data-urlencode "text=$1" \
  -d "disable_web_page_preview=true" >/dev/null 2>&1 || true; }

# GOLDEN copy before update (undoes install.sh classifier clobber)
cp /root/.hermes/patches/anthropic_billing_bypass.py /tmp/bypass.ORIG.py

notify "🔧 Hermes update started (${TS}). Chat goes dark on gateway restart; progress here. Log: ${LOGFILE}"

notify "1/7 📸 Snapshot ${SNAP}…"
"$HERMES" profile create "$SNAP" --clone-all >>"$LOGFILE" 2>&1 \
  && notify "1/7 ✅ Snapshot ok." || notify "1/7 ⚠️ snapshot issue — continuing (update has --backup)."

notify "2/7 ⬇️ hermes update --yes --backup…"
if "$HERMES" update --yes --backup >>"$LOGFILE" 2>&1; then
  notify "2/7 ✅ $("$HERMES" --version | head -1)"
else
  notify "2/7 ❌ UPDATE FAILED — on old code. Rollback: hermes profile use ${SNAP}"; exit 1
fi

notify "3/7 🔧 config migrate (NOTE: no --yes flag in v0.16.0+)…"
"$HERMES" config migrate >>"$LOGFILE" 2>&1 && notify "3/7 ✅ default migrated." || notify "3/7 ⚠️ check log."
R="3/7 satellites:"; for p in executor ha-bot voice-changer stable-2026-06-02; do
  R="${R} | ${p}: $("$HERMES" --profile "$p" config migrate 2>&1 | tail -1)"; done; notify "$R"

notify "4/7 🔑 reinstall bypass (HOME set)…"
( cd "$CLAUDE_AUTH_DIR" && HOME=/root ./install.sh ) >>"$LOGFILE" 2>&1 \
  && notify "4/7 ✅ bypass reinstalled." || notify "4/7 ⚠️ install.sh nonzero — verify."
# UNDO PITFALL 1: install.sh ships vanilla bypass w/o classifier
if [ "$(grep -c _classify_complexity /root/.hermes/patches/anthropic_billing_bypass.py)" -lt 2 ]; then
  cp /tmp/bypass.ORIG.py /root/.hermes/patches/anthropic_billing_bypass.py
  notify "4/7 ♻️ classifier was clobbered by install.sh — restored from golden."
fi

notify "5/7 🔄 restart gateways (best-effort; update already cycled them)…"
systemctl --user restart hermes-gateway.service >>"$LOGFILE" 2>&1 || notify "5/7 ⏭️ user-bus restart unavailable (expected in systemd unit)."
[ "$RESTART_VOICE_CHANGER" = yes ] && systemctl --user restart hermes-gateway-voice-changer.service >>"$LOGFILE" 2>&1 || true

notify "6/7 🧪 bypass health…"; sleep 5
H="$("$HERMES" chat -q 'Reply with exactly: AUTH TEST OK' --provider anthropic -m claude-sonnet-4-6 -Q 2>>"$LOGFILE")"
echo "$H" | grep -q "AUTH TEST OK" && notify "6/7 ✅ Anthropic bypass WORKING." \
  || notify "6/7 ❌ bypass test failed. Got: $(echo "$H" | head -c 200)"

notify "7/7 🏁 Done. Log: ${LOGFILE}"
```
