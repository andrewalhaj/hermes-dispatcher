---
name: hermes-core-update-with-bypass
description: "Safe Hermes core update on a host using the hermes-claude-auth OAuth bypass and custom patch files. Covers the detached-runner pattern (update severs your own session), the install.sh classifier-clobber regression, config migration across satellite profiles, and the self-heal cron that protects patch files from future overwrites."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [hermes, update, oauth-bypass, patches, cron, self-heal, maintenance]
    created_by: agent
load_when:
  - "user asks to run hermes update / update Hermes core on a bypass host"
  - "user asks about the OAuth bypass breaking after an update"
  - "complex tasks stopped upgrading to Opus / classifier missing"
  - "user asks about protecting patch files from being overwritten"
  - "user asks about the delegation-checkpoint guard or patch-guard cron"
---

# Hermes Core Update (with OAuth bypass + custom patches)

This host runs Anthropic via the **hermes-claude-auth OAuth bypass**, plus custom
patch files. `hermes update` rebuilds the venv and **breaks the bypass**, and the
bypass's own `install.sh` **clobbers customizations**. This skill is the proven,
gated sequence that survives both.

## 0. Approval gate (iron rule)
`hermes update` is a gated mutation. Present analysis + risks + rollback, get
explicit greenlight, snapshot first. Never run it inline reflexively.

## Critical facts about THIS host
- **Agent class is `AIAgent`** (not `RunAgent`) in `run_agent.py`. Patches target `AIAgent`.
- **Bypass loads only on the Anthropic path** — `agent.anthropic_adapter` is imported
  lazily (`agent_init.py`, `api_mode == "anthropic_messages"`). DeepSeek-only sessions
  never trigger it. That's why provider-independent installs go in `sitecustomize.py`.
- **`sitecustomize.py`** lives in the venv site-packages and is the hermes-claude-auth
  import hook. Rebuilt by `hermes update` AND `install.sh`.
- **Patch files:** `~/.hermes/patches/anthropic_billing_bypass.py` (custom, ~931 lines,
  contains the complexity classifier `_classify_complexity`/`_maybe_upgrade_model`) and
  `~/.hermes/patches/delegation_checkpoint.py` (delegation guard).

> For HOW to install custom runtime behavior into the agent loop (monkeypatch seams,
> `AIAgent` class, `_execute_tool_calls`, deferred MetaPathFinder, isolated-subprocess
> testing, idempotency), see `references/runtime-patching-pattern.md`.
>
> For WHO refreshes the OAuth token (no daemon — lazy, request-triggered, in
> `anthropic_adapter`), the reusable refresh functions, the single-use-refresh-token
> RACE, and the **single-writer pattern** for sharing the bypass token with another
> process (e.g. a hardened container), see `references/oauth-token-refresh-and-sharing.md`.

## PITFALL 1 — install.sh clobbers the classifier (PROVEN 2026-06-06)
`hermes-claude-auth/install.sh` ships a **vanilla** `anthropic_billing_bypass.py`
WITHOUT the complexity classifier (it was 833 lines vs our customized 931). Running
install.sh silently overwrites the custom file → **complex tasks stop auto-upgrading
to Opus, silently**. The bypass still *works* (auth OK) so the regression is invisible
without checking `grep -c _classify_complexity`.
**Fix:** always restore the customized file from a golden copy after any install.sh run.

## PITFALL 2 — `config migrate --yes` flag removed in v0.16.0
Older runners used `hermes config migrate --yes`. v0.16.0 **removed `--yes`** →
`error: unrecognized arguments: --yes` and migration silently doesn't run.
Correct command is bare `hermes config migrate`. Verify with
`hermes config check | grep -i version` (want "Config version: N ✓").

## PITFALL 3 — satellite profiles don't auto-migrate
`hermes config migrate` only migrates the **default** profile. Satellites
(executor, ha-bot, voice-changer, stable-*) stay on the old version. Migrate each:
`hermes --profile <name> config migrate` (back up each config.yaml first).

## PITFALL 4 — the update severs your own session
The gateway restart in the update kills the controlling chat. Run the whole
sequence as a **detached system-level systemd-run unit** that reports each step
to Telegram out-of-band via the Bot API. Verify detachment works first:
`systemd-run --unit=test --collect /bin/bash -c '...'`.

## PITFALL 5 — system-level unit can't reach user systemd bus
A `systemd-run` unit (no user session bus) can't `systemctl --user restart`.
This is usually harmless: `hermes update` already cycles the gateways itself.
Don't treat the restart-step failure as fatal; verify gateway PIDs/start-times instead.

## PITFALL 6 — gateway units may not load ~/.hermes/.env → silent delegation 401 (PROVEN 2026-06-07)
The user-scoped gateway units (`~/.config/systemd/user/hermes-gateway*.service`)
may set only `Environment=` lines (PATH/VIRTUAL_ENV/HERMES_HOME) and **no
`EnvironmentFile=`**. Then `~/.hermes/.env` is NEVER loaded into the gateway
process env. Any feature resolving a key via `*_env` (e.g. delegation's
`api_key_env: DEEPSEEK_API_KEY`) sees an empty `os.environ`, falls through to a
stale cached value, and **401s silently** — subagents quietly stop spawning for
days with no alarm. The key on disk is fine; the env load is the bug.
**Diagnose:** `tr '\0' '\n' < /proc/$(systemctl --user show -p MainPID --value hermes-gateway.service)/environ | grep -cE '^(DEEPSEEK_API_KEY|ANTHROPIC|XAI)'` → 0 means nothing loaded.
**Fix (durable):** add `EnvironmentFile=-/root/.hermes/.env` (the `-` tolerates
absence/parse-skips) under `[Service]` in each gateway unit, `daemon-reload`,
restart. Verify `.env` is systemd-clean first (no `export ` prefix, no
`$`-expansion, well-formed `KEY=value`). Confirm post-restart: the same
`/proc/PID/environ` grep now shows the keys loaded.
**Immediate unblock (no restart of THIS session):** set the literal in
`config.yaml` `delegation.api_key` — it overrides the env path and the stale
cache. Restarting the **default** gateway bounces the current chat's backend
(do it last / let the user trigger); restarting **ha-bot** is safe from the
default session.
**Detection:** add a delegation health probe to the infra watchdog (resolve the
key the same way Hermes does — config literal first, then env — and
`GET https://api.deepseek.com/v1/models`; P1 on 401) so this never goes silent
again.

## The proven sequence

### 1. Pre-flight (read-only)
```bash
hermes update --check                       # how many commits behind
hermes --version
cd /usr/local/lib/hermes-agent && git rev-parse --short HEAD
ls /root/hermes-claude-auth/install.sh      # bypass reinstall source present?
ls ~/.claude/.credentials.json              # OAuth creds present?
```

### 2. Snapshot
```bash
hermes profile create pre-update-YYYY-MM --clone-all
cp ~/.hermes/patches/anthropic_billing_bypass.py /tmp/bypass.ORIG.py   # GOLDEN
```
Keep that golden copy — it's the only way to undo PITFALL 1.

### 3. Detached runner
Write a script (see `references/update-runner.md` for the full template) that:
1. snapshots, 2. `hermes update --yes --backup` (fatal-abort on failure),
3. `hermes config migrate` (default) + `config check` per satellite,
4. re-run bypass `install.sh` with `HOME=/root` set,
5. restart gateways (best-effort), 6. live `AUTH TEST OK` health call,
7. report each step to Telegram. Read the bot token at runtime from `.env`
(never inline — the credential filter mangles it; use a script file).
Launch: `systemd-run --unit=hermes-update-$(date +%s) --collect bash <script>`.

### 4. Post-update verification (THE PART THAT MATTERS)
```bash
hermes --version                                    # new version live?
hermes config check | grep -i version               # default v? ✓
for p in executor ha-bot voice-changer stable-2026-06-02; do
  hermes --profile $p config check | grep -i version; done
# classifier survived install.sh?
grep -c _classify_complexity ~/.hermes/patches/anthropic_billing_bypass.py   # want 2
# live bypass + classifier dry-run
hermes chat -q 'Reply with exactly: AUTH OK' --provider anthropic -m claude-sonnet-4-6 -Q
```
If classifier count is 0 → PITFALL 1 hit → restore from golden:
```bash
cp /tmp/bypass.ORIG.py ~/.hermes/patches/anthropic_billing_bypass.py
```

### 5. Restart + confirm new code
```bash
systemctl --user restart hermes-gateway.service hermes-gateway-ha-bot.service
# confirm PIDs started AFTER the update; grep gateway logs for:
#   [anthropic_billing_bypass] Bypass installed
#   [delegation-checkpoint] installed
```

## Self-heal cron (protects all of the above)
Because install.sh / update overwrite the patch files, a daily watchdog restores
them from golden copies in `~/.hermes/references/patch-guard/`:
- Script: `~/.hermes/scripts/patch_guard.py` (no_agent cron, silent when healthy)
- Golden copies: `anthropic_billing_bypass.golden.py`, `delegation_checkpoint.golden.py`,
  `sitecustomize-block.golden.py`
- Checks MARKERS (not raw diff): `_classify_complexity` + `import delegation_checkpoint`
  in bypass; `def apply_patches` + `_deleg_checkpoint_patched` in guard; `delegation_checkpoint`
  in sitecustomize. On drift: backup → restore (bypass/guard) or re-append (sitecustomize)
  → syntax-check → report + restart command. **Does NOT auto-restart** (would surprise an
  active session); tells Andrew the command instead.
- Cron: `0 5 * * *`, deliver `telegram:-1003947663220,discord:#cron-jobs`.
**After any intentional patch change, refresh the golden copies** or the watchdog reverts you.
**Both-files rule (PROVEN 2026-06-07):** any intentional edit to a guarded patch file
must be applied to BOTH the live file AND its `golden.py` in the same change, or the
05:00 self-heal silently reverts it next run. (Editing only `delegation_checkpoint.py`
to remove a noisy startup line would have come back at 05:00 — golden had to be edited
too.) The self-heal triggers on MARKERS, not raw diff, so non-marker edits (cosmetic
log-line removals, etc.) won't *trigger* a restore on their own — but a later genuine
drift restore would reintroduce the line from a stale golden. Edit both, every time.

## Rollback
```bash
hermes profile use pre-update-YYYY-MM
cp /tmp/bypass.ORIG.py ~/.hermes/patches/anthropic_billing_bypass.py
cd /root/hermes-claude-auth && HOME=/root ./install.sh
systemctl --user restart hermes-gateway.service hermes-gateway-ha-bot.service
```
