---
name: delegation-checkpoint-guard
description: "Audit/tune the runtime delegation-checkpoint guard."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [token-optimization, delegation, patches, cron, gateway, cost]
    related_skills: [token-optimization, hermes-maintenance]
---

# Delegation-Checkpoint Guard

The delegation-checkpoint is a runtime patch that injects a one-time per-session
`[Delegation checkpoint: ...]` system-reminder when a session drifts into
delegation-worthy territory without ever calling `delegate_task`. It is a
SALIENCE NUDGE — it raises the odds of delegation, it cannot force it.

## When to Load

- Tuning or auditing the delegation nudge thresholds
- Investigating why a costly session was NOT caught
- `delegation-checkpoint] sitecustomize install failed` noise in logs/tool output
- Any edit to `~/.hermes/patches/delegation_checkpoint.py`
- Confirming a memory note about `HERMES_DELEG_CHECKPOINT` against live state

## Live-State First (critical)

Memory notes about this flag have been STALE before. ALWAYS verify live, never
trust a stored "it's off/on" claim:

```bash
# Is the flag set anywhere? (unset => defaults to 'on')
grep -rn "HERMES_DELEG_CHECKPOINT" ~/.hermes/.env ~/.hermes/profiles/*/.env \
  ~/.config/systemd/user/hermes-gateway.service 2>/dev/null
# Is it actually installed + firing? (the only real proof)
journalctl --user -u hermes-gateway --no-pager -n 500 2>/dev/null \
  | grep "delegation-checkpoint"
```
The `installed (...)` line logs the active thresholds on every gateway start.
A `fired:` line proves a real session tripped it.

## Architecture

- **Guard module:** `~/.hermes/patches/delegation_checkpoint.py`
- **Golden baseline:** `~/.hermes/references/patch-guard/delegation_checkpoint.golden.py`
- **Self-heal cron:** "Patch Guard Self-Heal" (`~/.hermes/scripts/patch_guard.py`, 05:00 UTC)
  restores the live file FROM golden ONLY IF a marker goes missing.
  Markers: `["def apply_patches", "_deleg_checkpoint_patched"]`.
- **Install path:** `sitecustomize.py` (in the venv site-packages) adds the
  patches dir to `sys.path` at interpreter startup and calls `apply_patches()`.
  It wraps `AIAgent._execute_tool_calls`; per-session counters live on the
  agent instance (`_deleg_ckpt_*`), so the latch is naturally per-session.

## Dual-Trigger + Re-Firing Watermark (the key design)

**Since 2026-06-09 the guard is NOT one-shot.** First fire happens when
`delegate_task == 0` AND EITHER:
- **Trigger A** (terminal-grind): `terminal >= HERMES_DELEG_TERMINAL_MIN` (default 30)
  AND `current_context_tokens >= HERMES_DELEG_TOKEN_MIN` (default 80000)
- **Trigger B** (inline authoring): `write_file + patch >= HERMES_DELEG_WRITE_MIN` (default 6)

After the first fire it RE-FIRES every further `WRITE_MIN` writes while delegation
stays zero (watermark in `self._deleg_ckpt_fired_at_writes` = write-count at last
fire). One `delegate_task` call silences it for the rest of the session. Rationale:
the original one-shot latch nudged the $107 blowout session ONCE at write #6, then
went silent for the next 50 writes — a per-volume nag scales with the size of the
mistake. (`_deleg_ckpt_fired` is retained for compat but no longer gates.)

**Synthetic test invariant** (run after any edit; see Editing Procedure step 5):
with default WRITE_MIN=6, pure-write rounds must fire at exactly **[6, 12, 18]**,
and a session that delegates mid-way must go permanently silent. A fast inline
harness: fake `AIAgent` class + fake tool_calls objects, call the wrapped
`_execute_tool_calls` in a loop, assert on `"[Delegation checkpoint"` presence
in the last tool message.

**Why B exists — the lesson that justified this skill.** A session that
*generates* large file contents inline (heavy `write_file`/`patch`) bills huge
OUTPUT tokens while its INPUT context stays tiny. Trigger A (context-size based)
is structurally BLIND to it. Real example: a session ran 7 patch + 3 write with
only 1,691 input tokens and cost **$100** in output — under A's terminal floor,
under A's token floor, never caught. Output tokens, not input, were the bill.
Trigger B watches write-volume directly and catches exactly this class.

## Editing Procedure (gated — it's a patch file)

1. **Verify golden == live first:** `diff -q <golden> <live>`. If identical, you
   can edit live then `cp live golden` at the end. If they differ, reconcile first.
2. Back up BOTH files + the systemd unit (`.bak-<timestamp>`).
3. Edit live `delegation_checkpoint.py`. Keep BOTH markers intact or patch_guard
   will silently restore the old version on its next run.
4. **Compile-check:** `python3 -c "import py_compile; py_compile.compile('delegation_checkpoint.py', doraise=True)"`
5. **Synthetic trigger test** (prove it fires on the target pattern AND stays
   silent on a light session) — see scripts/test_trigger.py pattern below.
6. **Sync golden:** `cp <live> <golden>` so a future heal restores the NEW logic.
   Verify golden compiles too.
7. Reload (see below). Thresholds are read at IMPORT time — no restart, no effect.

## Subprocess Noise Fix (HERMES_PATCHES_DIR)

`sitecustomize` resolves the patches dir via
`os.environ.get("HERMES_PATCHES_DIR", os.path.expanduser("~/.hermes/patches"))`.
The gateway resolves `~` fine, but spawned terminal subprocesses can fail to and
emit `ModuleNotFoundError: No module named 'delegation_checkpoint'` tracebacks
into tool output (benign — the guard isn't needed in those subprocesses, but it's
noise and trips false "Tool returned error" warnings). Fix: pin an ABSOLUTE path
in the gateway unit so subprocesses inherit it:
```ini
Environment="HERMES_PATCHES_DIR=/root/.hermes/patches"
```
Then `systemctl --user daemon-reload` + restart. Verify it's in the live env:
`tr '\0' '\n' < /proc/<MAINPID>/environ | grep HERMES_PATCHES_DIR`

## Gateway Reload (deadlock-safe)

Thresholds + env changes need a gateway restart. NEVER restart from inside the
gateway (self-restart deadlock). Use the detached out-of-cgroup pattern from the
`hermes-maintenance` skill (`references/gateway-restart-deadlock.md`):
```bash
export XDG_RUNTIME_DIR=/run/user/$(id -u)
systemctl --user daemon-reload   # only if the unit file changed
systemd-run --user --on-active=2 --unit=hermes-gw-delegfix \
  --description="gateway reload: deleg-checkpoint" \
  systemctl --user restart hermes-gateway.service
# then END THE TURN — verify on the next turn:
#   systemctl --user show hermes-gateway -p MainPID,ActiveState,ExecMainStartTimestamp
#   journalctl --user -u hermes-gateway -n 50 | grep "installed"
#   systemctl --user reset-failed hermes-gw-delegfix.{service,timer}
```

## The Checkpoint Patch Family (2026-06-10)

Three sibling patches now live under `~/.hermes/patches/`, all using the same MetaPathFinder + `_execute_tool_calls` wrapper pattern:

| File | Marker | Purpose | Re-fires? |
|---|---|---|---|
| `delegation_checkpoint.py` | `_deleg_checkpoint_patched` | Delegation nudge when write/terminal volume is high | Yes, every WRITE_MIN more writes |
| `skill_review_checkpoint.py` | `_skill_review_patched` | Skill-sweep nudge on complex tasks with no skill loaded | No (latch-once) |
| `memory_checkpoint.py` | `_memory_checkpoint_patched` | Memory-pressure nudge on every memory write ≥88% | Yes, every write while above warn% |
| `domain_ownership_checkpoint.py` | `_domain_ownership_patched` | Ownership-routing nudge | — |
| `write_gate.py` | `_write_gate_patched` | **ENFORCEMENT (not a nudge):** hard-blocks gated actions pre-execution | n/a — blocks every gated call |

**write_gate.py is the family's first ENFORCEMENT patch (built 2026-06-11)** — it intercepts BEFORE execution instead of appending text after. Key design facts:
- **Neutralization via argument rewrite**, not call-dropping: gated `terminal` commands are rewritten to `echo '<block msg>'`; gated `write_file`/`patch` paths are redirected to `/dev/null`; then the block message is appended to the tool result. This guarantees every `tool_call_id` still gets a result (provider-agnostic) while the gated action never executes.
- **Greenlight = arm token:** `python3 ~/.hermes/patches/write_gate.py arm "<note>" --ttl 600` (max 3600, refuses empty note) writes `~/.hermes/.write_gate_grant` (JSON with `expires` epoch). Valid grant → gated actions pass with a stderr `armed-pass` line. Also `disarm` / `status`. All arms/blocks append to `~/.hermes/references/write-gate-audit.log`.
- **Gated:** /etc, config.yaml, .env, AGENTS/SOUL.md, skills/, profiles/, cron/, patches/ + patch-guard goldens (self-protection), systemd units, /usr/local/lib/hermes-agent; systemctl/docker/apt/pip state verbs, reboot/shutdown/kill -9/chmod 777/chown -R, scp always, ssh only with state-changing tokens (read-only `ssh host docker ps` passes; `ssh host docker restart x` blocks), redirect-writes naming gated path literals. NOT gated: memories/ (autonomous by doctrine), references/ (except patch-guard).
- **Fail-open:** any internal guard exception ALLOWS the action and logs to stderr — a buggy gate must never brick the agent. `HERMES_WRITE_GATE=off` disables; `HERMES_WRITE_GATE_MODE=warn` executes but appends a warning (fallback mode).
- **Honesty mechanism, not adversarial security** — the agent arms it only after explicit user greenlight; the audit log makes every arm reviewable.
- Synthetic test: `~/.hermes/patches/test_write_gate.py` (10 cases incl. armed-pass, expired grant, warn mode, fail-open) — run it after ANY edit, then sync golden.

All three are:
- Chained from `anthropic_billing_bypass.apply_patches()` (Anthropic path)
- Installed at startup from `sitecustomize.py` (all providers)
- Covered by `patch_guard.py` (daily 05:00) with their own golden copies + markers
- Disabled via their own `HERMES_*_CHECKPOINT=off` env var

**When building a new checkpoint patch**, copy `delegation_checkpoint.py` as the template for NUDGES (post-execution text append); copy `write_gate.py` as the template for ENFORCEMENT (pre-execution interception via argument rewrite). Key invariants:
1. Module-level `_INSTALL_STARTED` prevents double-arming the MetaPathFinder.
2. Class-level `_MARKER` (via `setattr`) prevents double-wrapping `_execute_tool_calls`.
3. All logic in try/except — guard errors must be no-ops, never crash the agent.
4. Chain call at the END of `anthropic_billing_bypass.apply_patches()` with its own try/except block.
5. Add a `_restore_full()` block in `patch_guard.py` with the two marker strings.
6. Copy golden: `cp <live> references/patch-guard/<name>.golden.py` and compile-check both.

**memory_checkpoint specifics** (differs from delegation pattern):
- Triggers on `memory` tool calls with `action=add` or `action=replace` (parsed from function arguments JSON).
- Reads live caps from `config.yaml` on each call — never uses the stale injected header.
- Warns at ≥88%, critical at ≥95%, target message is ≤80%.
- Re-fires on every write while above warn% (not latch-once) — the whole point is to keep reminding until actually compacted.
- Tunable via `HERMES_MEMCKPT_WARN_PCT`, `HERMES_MEMCKPT_CRIT_PCT`, `HERMES_MEMCKPT_TARGET_PCT`.

## Pitfalls

- **Stale memory about the flag.** It has read "off" while live logs showed it
  firing. Probe live, the live system wins.
- **Forgetting to sync golden.** Edit live only → next patch_guard heal silently
  reverts to old thresholds. Always `cp live golden` after a validated edit.
- **Expecting an instant effect.** Tunables are import-time. No restart = no change.
- **Trigger A only catches grind, not generation.** If a costly session had low
  terminal + low context but high output, it's a Trigger B case — check write count.
- **The nudge cannot force delegation.** It's a salience reminder. Pair it with the
  SOUL.md hard delegation rule for belt-and-suspenders.
