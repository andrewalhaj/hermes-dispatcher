---
name: cloudflare-tunnel-expose
description: "Expose self-hosted services via Cloudflare Tunnel"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [cloudflare, cloudflared, tunnel, https, dns, selfhost, expose]
    related_skills: [nextjs-prisma-docker-selfhost, infra-incident-triage]
    created_by: agent
load_when:
  - "exposing a self-hosted app/service to the internet over HTTPS"
  - "setting up or debugging cloudflared / Cloudflare Tunnel"
  - "cloudflared errors: control stream failure, 530, invalid tunnel secret"
  - "user wants a domain/subdomain pointed at a local port"
---

# Cloudflare Tunnel — Expose Self-Hosted Services

Proven 2026-06-11 putting Mealio (hil-1:3015) behind `https://mealio.andrewskingdom.com`.
Gives free HTTPS, hides origin IP, no open ports. Preferred over raw `IP:port` sharing
(plaintext logins, no rate limiting, IP exposure).

## Setup path (dashboard-token flow — simplest)

1. User creates tunnel at one.dash.cloudflare.com → Networks → Tunnels → Create. They copy the
   connector token (`eyJ...` blob from the `cloudflared service install eyJ...` command).
2. **Token anatomy:** base64 JSON `{"a":"<accountId>","t":"<tunnelId>","s":"<secret>"}`.
   ALWAYS `base64 -d` it on receipt — compare `t` against any previous token to detect that the
   user recreated the tunnel (new tunnel = old token dead).
3. Install as systemd service (Linux box, not the .exe command the dashboard shows):
   `cat templates/cloudflared.service` — token read from a `chmod 600` file, never inline.
4. User adds Public Hostname in the tunnel's dashboard page: subdomain + domain, type HTTP,
   URL `localhost:<port>`. Config pushes to the connector live — no restart needed.
5. Verify: service logs show `Updated to new configuration config="{\"ingress\":[...]}"` followed by
   `Registered tunnel connection` ×4, then `curl -s -o /dev/null -w "%{http_code}" https://host` → app status.

## Pitfalls (each one cost a debugging round live)

- **QUIC masks auth errors.** `control stream encountered a failure while serving` on repeat is
  USELESS — it's the generic QUIC-side symptom for several distinct causes. Re-run with
  `--protocol http2` and the real error surfaces (live case: `Unauthorized: Invalid tunnel secret`).
  Keep `--protocol http2` in the service unit permanently; nothing of value is lost.
- **`Invalid tunnel secret`** = the token's `s` no longer matches the tunnel (tunnel deleted/recreated,
  token rotated). Decode both tokens; if tunnel IDs differ, it IS a different tunnel. Get a fresh
  token from the current tunnel's install command.
- **HTTP 530 with all connections registered** = DNS CNAME points at a DIFFERENT (old/deleted) tunnel.
  Happens when the hostname existed on a previous tunnel: Cloudflare won't overwrite the stale record
  when the new tunnel adds the same hostname. Fix: edit the `<sub>` CNAME in DNS → Records to target
  `<current-tunnel-id>.cfargotunnel.com`, or delete the record and re-save the Public Hostname entry.
- **No Public Hostname configured** also presents as control-stream failures/crash-looping — the
  connector registers but has no ingress. Check the dashboard before chasing connector-side causes.
- **Long tokens get mangled by shell middleware.** If the platform/sanitizer truncates or rewrites the
  `eyJ...` blob in commands (symptom: `Provided Tunnel token is not valid` with a short byte count),
  do NOT keep pasting it into shell strings. Reconstruct it from decoded JSON fields via a Python
  heredoc writing to a file, verify `wc -c` (~180-190 chars) and `base64 -d` round-trip, then have the
  service read it: `ExecStart=/bin/bash -c '... --token "$(cat /root/.cloudflared/token)"'`.
- **`cloudflared tunnel login`** (cert-based flow) needs an interactive browser and prints its URL to a
  TTY — on a headless server prefer the dashboard-token flow; don't fight the login flow.
- **Local negative DNS cache on the origin server.** Right after the DNS record is created, the origin
  box itself may return `Could not resolve host` (curl exit 6) while the record already resolves
  globally. Verify with `dig @1.1.1.1 <host> +short` (authoritative-ish view), then test the tunnel with
  `curl --resolve <host>:443:<cf-ip> https://<host>` to bypass the stale local resolver. Don't declare
  the setup broken — external clients resolve fine immediately.

## Verification gate

1. `systemctl status cloudflared` → active, logs show ≥1 `Registered tunnel connection` and the
   expected ingress hostname in `Updated to new configuration`.
2. `curl -s -o /dev/null -w "%{http_code}" https://<hostname>` → your app's normal status (not 530/502).
   530 = DNS→tunnel mismatch (above). 502 = connector up but origin port wrong/down.
3. Title/content check through the tunnel, not just status code.

Support files: `templates/cloudflared.service` (systemd unit with file-read token + http2).
