#!/usr/bin/env bash
# One-shot: restart hermes-dashboard OUTSIDE the gateway process tree.
# Run via a no_agent cron (cronjob action=create no_agent=True script=this).
# The gateway self-protection refuses `systemctl restart hermes-dashboard`
# from inside an agent turn (SIGTERM propagates and kills the command);
# a no_agent cron tick is a fresh process not parented by the gateway, so it works.
#
# Stdout is delivered verbatim by the cron, giving a verification line.
# Adjust SERVICE / PORT / HEALTH for other companion services.
SERVICE=hermes-dashboard
PORT=8787

systemctl restart "$SERVICE"
sleep 4
echo "service: $(systemctl is-active "$SERVICE")"

# Smoke-check a representative API route. Edit to a route that proves the fix loaded.
curl -s "http://127.0.0.1:${PORT}/api/chat/sessions" | python3 -c "
import sys, json
try:
    s = json.load(sys.stdin)
    print('sessions:', len(s), '| sample:', [x.get('id','')[:18] for x in s[:3]])
except Exception as e:
    print('api check failed:', e)
"
